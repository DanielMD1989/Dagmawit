"""Browser tests for the BUILT app (dist/), as a black box.

A fake Supabase answers over HTTP exactly like the real REST API (PostgREST),
so the real supabase-js library runs. Two browser contexts share one fake
database = two phones. The tests only tap buttons and read what the phone
stored (localStorage) and what reached the "cloud" (the fake database).

usage:  python3 -I tests/e2e/run_e2e.py dist tests/e2e/out
"""
import json, sys, pathlib, copy, re
from urllib.parse import urlparse, parse_qs
from playwright.sync_api import sync_playwright

DIST = pathlib.Path(sys.argv[1]).resolve(); OUT = pathlib.Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
HERE = pathlib.Path(__file__).parent
CFG = (DIST / 'config.js').read_text()
SUPA_URL = re.search(r'SUPABASE_URL:\s*"([^"]+)"', CFG).group(1)
REF = urlparse(SUPA_URL).hostname.split('.')[0]

SEED = json.loads((HERE / 'seed-old-format.json').read_text())          # old format: paid totals, no payment lists
SEED['events'] = [{"id": "ev1", "name": "Bole fashion show", "date": "2026-11-20", "checklist": [{"txt": "20 dresses", "done": False}]}]
SEED['customers'][0]['note'] = 'likes loose fit, "no" zips'
SEED['customers'][0]['m']['neck'] = 34

# ---------------- fake Supabase REST (PostgREST) ----------------
def jsonb(x): return json.loads(json.dumps(x, sort_keys=True))          # jsonb reorders keys
def pg_ts(ts): return ts.replace('Z', '+00:00') if isinstance(ts, str) else ts   # timestamptz comes back as +00:00
DB = {'shared': {'id': 'shared', 'content': jsonb(SEED), 'updated_at': '2026-11-01T08:00:00.000+00:00'}}
CORS = {'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*', 'access-control-expose-headers': '*'}
WRITES = {'ok': 0, 'conflict': 0}

def project(row, sel):
    cols = [c.strip() for c in (sel or '*').split(',')]
    return copy.deepcopy(row) if cols == ['*'] else {c: copy.deepcopy(row.get(c)) for c in cols}

def supabase_handler(route):
    req = route.request
    if req.method == 'OPTIONS': return route.fulfill(status=204, headers=CORS)
    u = urlparse(req.url)
    if u.path.startswith('/auth/'): return route.fulfill(status=200, headers={**CORS, 'content-type': 'application/json'}, body='{}')
    if not u.path.startswith('/rest/v1/business_data'): return route.fulfill(status=404, headers=CORS, body='')
    qs = parse_qs(u.query)
    eq = {k: v[0][3:] for k, v in qs.items() if v and v[0].startswith('eq.')}
    sel = qs.get('select', [None])[0]
    js = lambda status, data: route.fulfill(status=status, headers={**CORS, 'content-type': 'application/json'}, body=json.dumps(data))
    if req.method == 'GET':
        row = DB.get(eq.get('id'))
        return js(200, [project(row, sel)] if row else [])
    body = json.loads(req.post_data or 'null')
    if req.method == 'POST':
        rows = body if isinstance(body, list) else [body]
        for r in rows:
            if r['id'] in DB: return js(409, {'code': '23505', 'message': 'duplicate key value violates unique constraint'})
        for r in rows: DB[r['id']] = {'id': r['id'], 'content': jsonb(r.get('content')), 'updated_at': pg_ts(r.get('updated_at') or '2026-11-01T00:00:00+00:00')}
        return route.fulfill(status=201, headers=CORS, body='')
    if req.method == 'PATCH':
        cur = DB.get(eq.get('id'))
        if not cur or ('updated_at' in eq and cur['updated_at'] != eq['updated_at']):
            WRITES['conflict'] += 1
            return js(200, []) if sel else route.fulfill(status=204, headers=CORS, body='')
        if 'content' in body: cur['content'] = jsonb(body['content'])
        if 'updated_at' in body: cur['updated_at'] = pg_ts(body['updated_at'])
        WRITES['ok'] += 1
        return js(200, [project(cur, sel)]) if sel else route.fulfill(status=204, headers=CORS, body='')
    return route.fulfill(status=405, headers=CORS, body='')

def static_handler(route):
    path = urlparse(route.request.url).path.lstrip('/') or 'index.html'
    f = DIST / path
    if not f.is_file(): return route.fulfill(status=404, body='')
    ct = {'.js': 'application/javascript', '.css': 'text/css', '.html': 'text/html', '.png': 'image/png', '.json': 'application/json'}.get(f.suffix, 'application/octet-stream')
    return route.fulfill(body=f.read_bytes(), content_type=ct)

# ---------------- helpers ----------------
results, errors = [], []
def check(name, cond, detail=''): results.append((bool(cond), name, '' if cond else str(detail)[:400]))
FAKE_NOW = "(()=>{const RD=Date,off=new RD('2026-11-09T09:30:00+03:00').getTime()-RD.now();class D extends RD{constructor(...a){super(...(a.length?a:[RD.now()+off]))}static now(){return RD.now()+off}};window.Date=D;})();"
SESSION = {"access_token": "test-token", "refresh_token": "test-refresh", "token_type": "bearer", "expires_in": 3600, "expires_at": 4102444800,
           "user": {"id": "00000000-0000-0000-0000-000000000001", "email": "dagmawit@example.com", "aud": "authenticated", "role": "authenticated", "app_metadata": {}, "user_metadata": {}}}

def device(pw, name, signed_in=True):
    browser = pw.chromium.launch()
    ctx = browser.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, service_workers='block', accept_downloads=True)
    page = ctx.new_page()
    page.on('pageerror', lambda e: errors.append(f'[{name}] {e}'))
    page.on('console', lambda m: errors.append(f'[{name}] console: {m.text}') if m.type == 'error' and 'Failed to fetch' not in m.text and 'ERR_INTERNET_DISCONNECTED' not in m.text else None)
    ctx.route(re.compile(r'^https://[^/]*supabase\.co/'), supabase_handler)
    ctx.route(re.compile(r'^http://app\.test/'), static_handler)
    ctx.route(re.compile(r'^https://fonts\.(googleapis|gstatic)\.com/'), lambda r: r.fulfill(status=200, body=''))
    page.route_web_socket(re.compile('realtime'), lambda ws: None)     # live updates: accepted, silent
    page.add_init_script(FAKE_NOW)
    if signed_in: page.add_init_script(f"localStorage.setItem('sb-{REF}-auth-token', {json.dumps(json.dumps(SESSION))});")
    page.goto('http://app.test/index.html')
    return browser, ctx, page

local = lambda p: p.evaluate("JSON.parse(localStorage.getItem('dagmawit:data'))")
def idle(p, timeout=8000):
    p.wait_for_timeout(650)
    p.wait_for_function("localStorage.getItem('dagmawit:dirty')==='0' && !document.querySelector('#sync.saving')", timeout=timeout)
def refresh(p): p.evaluate("window.dispatchEvent(new Event('online'))"); idle(p)
def offline(ctx, p): ctx.set_offline(True); p.evaluate("window.dispatchEvent(new Event('offline'))")
def online(ctx, p): ctx.set_offline(False); refresh(p)
def shot(p, name, full=True): p.wait_for_timeout(500); p.screenshot(path=str(OUT / f'{name}.png'), full_page=full)
def sheet_shot(p, name):
    p.wait_for_timeout(450); h = p.evaluate("document.getElementById('sheet').scrollHeight")
    p.set_viewport_size({'width': 390, 'height': max(844, h + 30)}); p.wait_for_timeout(300)
    p.locator('#sheet').screenshot(path=str(OUT / f'{name}.png')); p.set_viewport_size({'width': 390, 'height': 844})
def close_sheets(p): p.keyboard.press('Escape'); p.wait_for_timeout(300)
def paid_sum(o): return sum(x['amount'] for x in o.get('payments', []))
def cash(d):   # independent re-implementation of the money rule, used as the test's oracle
    inc = sum(paid_sum(o) for o in d['orders'] if o.get('currency') != 'foreign' for _ in [0])
    inc = sum(p['amount'] for o in d['orders'] if o.get('currency') != 'foreign' for p in o['payments'])
    spent = sum(e['amount'] for e in d['expenses'] if not e.get('loanId'))
    repaid = sum(e['amount'] for e in d['expenses'] if e.get('loanId'))
    return inc + sum(l['total'] for l in d['loans']) - spent - repaid - sum(a['value'] for a in d['assets'])

with sync_playwright() as pw:
    # ================= PART 1: two phones, one database =================
    bA, ctxA, A = device(pw, 'A'); bB, ctxB, B = device(pw, 'B')
    for p in (A, B): p.wait_for_selector('#appView', state='visible', timeout=20000)
    idle(A); idle(B); refresh(A); refresh(B)
    c = DB['shared']['content']
    n_paid = len([o for o in SEED['orders'] if o['paid'] > 0])
    check('upgrade: each paid order has exactly one payment', sum(len(o['payments']) for o in c['orders']) == n_paid and all(len(o['payments']) == 1 for o in c['orders'] if o['paid'] > 0))
    check('upgrade: total money unchanged', sum(paid_sum(o) for o in c['orders']) == sum(o['paid'] for o in SEED['orders']))
    check('upgrade: events and customers kept', c['events'] == jsonb(SEED['events']) and c['customers'] == jsonb(SEED['customers']))
    check('both phones hold the cloud copy', jsonb(local(A)) == c == jsonb(local(B)))

    offline(ctxA, A)
    A.click('#addBtn'); A.click('#sheet [data-act=spent]'); A.fill('#ex_amt', '777'); A.click('#ex_cats [data-cat=Fuel]'); A.click('#ex_save'); A.wait_for_timeout(500)
    check('offline: kept on the phone and shown as not synced', 'Not synced' in A.inner_text('#sync') and any(e['amount'] == 777 for e in local(A)['expenses']))

    owing = next(o for o in c['orders'] if o['total'] - paid_sum(o) >= 1000)
    B.click('[data-act=gotPaid]'); B.click(f'#gpList [data-id="{owing["id"]}"]'); B.fill('#pa_amt', '1000'); B.click('#pa_save'); idle(B)
    B.click('[data-act=spent]'); B.fill('#ex_amt', '555'); B.click('#ex_cats [data-cat=Grocery]'); B.click('#ex_save'); idle(B)
    check('B reached the cloud', any(e['amount'] == 555 for e in DB['shared']['content']['expenses']))

    online(ctxA, A)
    c = DB['shared']['content']; o = next(x for x in c['orders'] if x['id'] == owing['id'])
    check('reconnect: A offline expense merged in', any(e['amount'] == 777 for e in c['expenses']))
    check('reconnect: B expense and payment kept', any(e['amount'] == 555 for e in c['expenses']) and paid_sum(o) == paid_sum(owing) + 1000 and o['paid'] == paid_sum(o))
    refresh(B)
    check('B sees A expense', any(e['amount'] == 777 for e in local(B)['expenses']))

    # both phones edit at the same moment through the screens
    A.click('nav [data-tab=expenses]'); B.click('nav [data-tab=expenses]')
    ids = A.evaluate("[...document.querySelectorAll('#view [data-act=editExpense]')].map(b=>b.dataset.id)")
    A.click(f'#view [data-act=editExpense][data-id="{ids[0]}"]'); A.fill('#ex_note', 'edited on A')
    B.click(f'#view [data-act=editExpense][data-id="{ids[1]}"]')
    A.click('#ex_save'); B.click('#ex_del')                                   # no waiting in between
    idle(A); idle(B); refresh(A); refresh(B)
    c = DB['shared']['content']
    check('same moment: A edit kept', next((e for e in c['expenses'] if e['id'] == ids[0]), {}).get('note') == 'edited on A')
    check('same moment: B delete kept', not any(e['id'] == ids[1] for e in c['expenses']))
    check('same moment: the second save was refused as stale, then merged and retried', WRITES['conflict'] >= 1, WRITES)
    check('same moment: both phones end identical to the cloud', jsonb(local(A)) == c == jsonb(local(B)))
    check('events still untouched', c['events'] == jsonb(SEED['events']))
    bA.close(); bB.close()

    # ================= PART 2: every screen and flow on one phone =================
    br, ctx, P = device(pw, 'P'); P.wait_for_selector('#appView', state='visible', timeout=20000); idle(P)
    shot(P, '01-home')
    d = local(P)
    check('home: cash in hand matches the money rules (incl. borrowed money)', f"{round(cash(d)):,}" in P.inner_text('.hero'), (cash(d), P.inner_text('.hero')[:60]))
    check('home: three quick actions', P.locator('.quick button').count() == 3)

    P.click('nav [data-tab=orders]'); shot(P, '02-orders')
    first = P.evaluate("document.querySelector('#view [data-act=openOrder]').dataset.id")
    P.click('[data-act=ordFilter][data-f=paid]'); shot(P, '03-orders-paid'); P.click('[data-act=ordFilter][data-f=owes]')
    P.click(f'#view [data-act=openOrder][data-id="{first}"]'); sheet_shot(P, '04-order-page')
    P.click('#sheet [data-act=recordPayment]'); sheet_shot(P, '05-payment')
    P.fill('#pa_amt', '99999999'); P.click('#pa_save')
    check('overpayment refused with a clear message', 'more than' in P.inner_text('#pa_amt_err'))
    before = len(next(o for o in local(P)['orders'] if o['id'] == first)['payments'])
    P.fill('#pa_amt', '500'); P.click('#pa_save'); P.wait_for_timeout(300)
    check('after saving a payment you are back on the order page', P.inner_text('.sheethead h2') == 'Order')
    check('payment stored with its date', len(next(o for o in local(P)['orders'] if o['id'] == first)['payments']) == before + 1)
    P.click('#sheet [data-act=editPayment] >> nth=-1'); P.click('#pa_del'); P.wait_for_timeout(300)
    check('payment deleted', len(next(o for o in local(P)['orders'] if o['id'] == first)['payments']) == before)
    P.click('#toast [data-act=undo]'); P.wait_for_timeout(300)
    check('undo brings it back', len(next(o for o in local(P)['orders'] if o['id'] == first)['payments']) == before + 1)
    P.click('#sheet [data-act=editOrder]'); sheet_shot(P, '06-order-form'); close_sheets(P)

    P.click('nav [data-tab=home]'); P.click('[data-act=gotPaid]'); sheet_shot(P, '07-got-paid')
    tot = P.locator('#gpList .row').count(); P.fill('#gpQ', 'hanna')
    vis = P.evaluate("[...document.querySelectorAll('#gpList .row')].filter(r=>r.style.display!=='none').length")
    check('got paid: search narrows the list', 0 < vis < tot, (vis, tot)); close_sheets(P)
    P.click('nav [data-tab=orders]'); P.click('#view [data-act=whoOwes]'); sheet_shot(P, '08-who-owes'); close_sheets(P)

    P.click('nav [data-tab=home]'); P.click('[data-act=spent]')
    P.click('#ex_cats [data-cat=Rent]'); P.wait_for_timeout(100)
    check('spent: rent suggested as home from history', P.evaluate("document.querySelector('#ex_scope .on').dataset.v") == 'home', P.inner_text('#ex_sugg'))
    P.click('#ex_cats [data-cat=Fabric]')
    check('spent: fabric suggested as work', P.evaluate("document.querySelector('#ex_scope .on').dataset.v") == 'biz')
    sheet_shot(P, '09-spent')
    P.click('#ex_save'); check('spent: amount required (inline)', 'amount' in P.inner_text('#ex_amt_err').lower()); close_sheets(P)

    P.click('nav [data-tab=expenses]'); shot(P, '10-expenses')
    n = len(local(P)['expenses'])
    P.click('#view [data-act=editExpense] >> nth=0'); P.click('#ex_del'); P.wait_for_timeout(300)
    check('expense deleted', len(local(P)['expenses']) == n - 1)
    P.click('#toast [data-act=undo]'); P.wait_for_timeout(300)
    check('undo restores it', len(local(P)['expenses']) == n)
    P.click('[data-act=expMonth][data-d="-1"]'); check('month switch', 'October 2026' in P.inner_text('.monthsw'))

    P.click('nav [data-tab=reports]'); shot(P, '11-reports')
    P.click('#view [data-act=repPick] >> nth=3'); check('tap a month bar', 'September 2026' in P.inner_text('.monthsw'))
    P.click('#view [data-act=go][data-tab=audit]'); shot(P, '12-check-numbers')
    P.click('#menuBtn'); shot(P, '13-menu', False)
    P.click('#sideItems [data-tab=loans]'); shot(P, '14-loans')
    P.click('#view [data-act=openLoan] >> nth=0'); sheet_shot(P, '15-loan'); close_sheets(P)
    P.click('#menuBtn'); P.click('#sideItems [data-tab=customers]'); shot(P, '16-customers')
    P.click('#view [data-act=openCustomer] >> nth=0'); sheet_shot(P, '17-customer')
    check('customer sheet is view only', P.locator('#sheet input').count() == 0); close_sheets(P)
    with P.expect_download() as dl: P.click('[data-act=customersCsv]')
    csv = pathlib.Path(dl.value.path()).read_text(encoding='utf-8-sig')
    check('customer CSV: every customer, extra measurement column, quoted note', csv.count('\n') == len(SEED['customers']) and 'neck (cm)' in csv and '"likes loose fit, ""no"" zips"' in csv)
    P.click('#addBtn'); sheet_shot(P, '18-add'); close_sheets(P)
    P.click('#menuBtn'); P.click('#sideItems [data-act=openSettings]'); sheet_shot(P, '19-settings'); close_sheets(P)

    P.click('nav [data-tab=home]'); P.click('#eyeBtn'); P.wait_for_timeout(200)
    check('hide money masks amounts', '•••••' in P.inner_text('.hero') and not re.search(r'\d{2},\d{3}', P.inner_text('.hero')))
    P.click('#eyeBtn')
    P.click('[data-act=newOrder]'); P.fill('#of_cust', 'Test Person'); P.fill('#of_total', '5000'); P.fill('#of_paid', '2000'); P.click('#of_save'); P.wait_for_timeout(400)
    check('new order opens its page with the first payment', '2,000' in P.inner_text('#sheet') and any(c['name'] == 'Test Person' for c in local(P)['customers'])); close_sheets(P)
    c0 = cash(local(P))
    P.click('#addBtn'); P.click('#sheet [data-act=newLoan]'); P.fill('#lf_lender', 'Cousin'); P.fill('#lf_total', '10000'); P.click('#lf_save'); idle(P)
    check('a loan adds to cash in hand', cash(local(P)) - c0 == 10000 and f"{round(c0 + 10000):,}" in P.inner_text('.hero'))
    check('everything reached the cloud', jsonb(local(P)) == DB['shared']['content'])
    br.close()

    br, ctx, S = device(pw, 'S', signed_in=False); S.wait_for_selector('#authView', state='visible', timeout=20000)
    check('sign-in screen has no create-account option', 'create' not in S.inner_text('#authView').lower())
    shot(S, '00-sign-in', False); br.close()

for ok, name, detail in results: print('PASS' if ok else 'FAIL', name, '' if ok else '-> ' + detail)
print('JS errors:', errors or 'none')
print('TOTAL', sum(1 for r in results if r[0]), '/', len(results))
sys.exit(0 if all(r[0] for r in results) and not errors else 1)
