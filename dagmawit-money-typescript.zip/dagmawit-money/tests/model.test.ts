/* Unit tests for the money rules, the data upgrade, the suggestions and
   the two-phone merge. Run: npm test   (also try: TZ=America/New_York npm test) */
import { describe, expect, it } from 'vitest';
import type { Doc, Expense } from '../src/types';
import {
  cashInHand, duplicateIds, mergeDocs, monthSeries, normalize, orderPaid, owedByCustomer, quickPicks,
  suggestCategory, suggestScope, totals
} from '../src/model';
import { addDays, addMonths, clone, monthRange, same, shiftYm, today, ymdOf } from '../src/util';

const legacy = {
  orders: [
    { id: 'o1', created: '2026-10-04', total: 12000, paid: 5000, payType: 'Advance', customer: 'Hanna', m: { bust: 90 }, needsAdj: true, delivery: '2026-11-20' },
    { id: 'o2', created: '2026-09-02', total: 8000, paid: 8000, payType: 'On delivery', delivered: true, deliveredOn: '2026-11-05' },
    { id: 'o3', created: '2026-11-01', total: 3000, paid: 0 },
    { id: 'w1', created: '2026-10-12', total: 180, paid: 180, currency: 'foreign' }
  ],
  expenses: [
    { id: 'e1', cat: 'Fabric', amount: 2000, date: '2026-10-05', scope: 'biz', note: 'cotton merkato' },
    { id: 'e2', cat: 'Grocery', amount: 1000, date: '2026-10-06', scope: 'home' },
    { id: 'r1', cat: 'Loan repayment', amount: 5000, date: '2026-10-07', scope: 'biz', loanId: 'l1' }
  ],
  loans: [{ id: 'l1', lender: 'Bank', total: 40000, created: '2026-07-01', purpose: 'business' }],
  assets: [{ id: 'a1', name: 'Machine', value: 10000, date: '2026-08-01' }],
  events: [{ id: 'ev1', name: 'Show', checklist: [{ txt: 'x', done: false }] }],
  customers: [{ id: 'c1', name: 'Hanna', phone: '0911', m: { bust: 90, neck: 30 } }],
  settings: { currency: 'Birr', bagRate: 80 }
};
const fresh = (): Doc => normalize(clone(legacy));
const order = (d: Doc, id: string) => d.orders.find(o => o.id === id)!;

describe('dates use the local calendar', () => {
  it('handles month ends and years', () => {
    expect(addMonths('2026-01-31', 1)).toBe('2026-02-28');
    expect(shiftYm('2026-01', -1)).toBe('2025-12');
    expect(monthRange('2028-02')[1]).toBe('2028-02-29');
    expect(today()).toBe(ymdOf(new Date()));
  });
});

describe('one-time upgrade of old data', () => {
  const d = fresh();
  it('turns the old paid total into one dated payment', () => {
    expect(order(d, 'o1').payments).toEqual([{ id: 'm_o1', amount: 5000, date: '2026-10-04', note: 'Paid before payment history was kept' }]);
    expect(order(d, 'o2').payments[0]!.date).toBe('2026-11-05');   // on delivery: dated on delivery
    expect(order(d, 'o3').payments).toEqual([]);
  });
  it('keeps planner fields, events and customers untouched', () => {
    expect(order(d, 'o1')).toMatchObject({ m: { bust: 90 }, needsAdj: true, delivery: '2026-11-20' });
    expect(same(d.events, legacy.events)).toBe(true);
    expect(same(d.customers, legacy.customers)).toBe(true);
    expect(d.settings.bagRate).toBe(80);
  });
  it('dates each loan', () => expect(d.loans[0]!.received).toBe('2026-07-01'));
  it('is deterministic and idempotent', () => {
    expect(same(fresh(), d)).toBe(true);
    expect(same(normalize(clone(d)), d)).toBe(true);
  });
  it('captures a payment added by a phone still on the old version', () => {
    const x = clone(d); x.orders[0]!.paid = 7000;
    const n = normalize(x);
    expect(orderPaid(n.orders[0]!)).toBe(7000);
    expect(n.orders[0]!.payments).toHaveLength(2);
  });
});

describe('money rules', () => {
  const d = fresh(), all = totals(d, null, null);
  it('counts income from local payments; website orders separately', () => {
    expect(all.income).toBe(13000);
    expect(all.fIncome).toBe(180);
  });
  it('does not count loan repayments as expenses', () => {
    expect([all.work, all.home, all.repaid]).toEqual([2000, 1000, 5000]);
  });
  it('profit = income − work expenses', () => expect(all.profit).toBe(11000));
  it('cash = income + borrowed − spent − repaid − assets', () => {
    expect(all.net).toBe(13000 + 40000 - 3000 - 5000 - 10000);
    expect(cashInHand(d)).toBe(all.net);
  });
  it('dates income by payment', () => {
    expect(totals(d, '2026-10-01', '2026-10-31').income).toBe(5000);
    expect(totals(d, '2026-11-01', '2026-11-30').income).toBe(8000);
  });
  it('month series ends at all-time cash', () => {
    const s = monthSeries(d, 3, '2026-11');
    expect(s).toHaveLength(3);
    expect(s[2]!.cashEnd).toBe(all.net);
  });
  it('groups who owes', () => expect(owedByCustomer(d)[0]!.left).toBe(7000));
});

describe('learning: work or home, category, quick picks', () => {
  const ex = (id: number, cat: string, amount: number, daysAgo: number, scope: 'biz' | 'home', note: string): Expense =>
    ({ id, cat, amount, date: addDays(today(), -daysAgo), scope, note });
  const L = normalize({ expenses: [
    ex(1, 'Rent', 9000, 40, 'home', 'house rent'), ex(2, 'Rent', 12000, 38, 'biz', 'shop rent bole'), ex(3, 'Rent', 9000, 10, 'home', 'house rent'),
    ex(4, 'Transport', 300, 3, 'biz', 'ride to merkato'), ex(5, 'Transport', 300, 2, 'biz', 'ride to merkato'), ex(6, 'Fabric', 300, 2, 'biz', 'merkato cotton')
  ] });
  it('learns rent is usually home', () => expect(suggestScope(L, 'Rent', '', '').scope).toBe('home'));
  it('learns "shop rent" is work (ignores the word "rent")', () => expect(suggestScope(L, 'Rent', 'shop rent', '').scope).toBe('biz'));
  it('falls back to sensible defaults', () => {
    expect(suggestScope(normalize({}), 'Fabric', '', '').scope).toBe('biz');
    expect(suggestScope(normalize({}), 'Grocery', '', '').scope).toBe('home');
  });
  it('suggests the category from note words', () => expect(suggestCategory(L, 'ride home')).toBe('Transport'));
  it('offers repeated entries as quick picks', () => {
    const qp = quickPicks(L);
    expect(qp).toHaveLength(2);
    expect(qp.some(p => p.cat === 'Rent' && p.scope === 'home' && p.amount === 9000)).toBe(true);
  });
});

describe('merging two phones', () => {
  const base = fresh();
  const A = clone(base), B = clone(base);
  A.expenses.push({ id: 'eA', cat: 'Fuel', amount: 500, date: '2026-11-08', scope: 'biz' });
  B.expenses.push({ id: 'eB', cat: 'Grocery', amount: 700, date: '2026-11-08', scope: 'home' });
  A.orders[0]!.payments.push({ id: 'pA', amount: 1000, date: '2026-11-08' });
  B.orders[0]!.payments.push({ id: 'pB', amount: 2000, date: '2026-11-09' });
  B.orders[0]!.clothType = 'Wedding dress';
  A.expenses = A.expenses.filter(e => e.id !== 'e2');
  B.customers[0]!.phone = '0922';
  const M = mergeDocs(base, normalize(A), normalize(B));
  it('keeps additions from both', () => expect(['eA', 'eB'].every(id => M.expenses.some(e => e.id === id))).toBe(true));
  it('keeps both payments on the same order and recomputes paid', () => {
    expect(M.orders[0]!.payments).toHaveLength(3);
    expect(M.orders[0]!.paid).toBe(8000);
  });
  it('keeps field edits and deletions', () => {
    expect(M.orders[0]!.clothType).toBe('Wedding dress');
    expect(M.expenses.some(e => e.id === 'e2')).toBe(false);
    expect(M.customers[0]!.phone).toBe('0922');
    expect(same(M.events, legacy.events)).toBe(true);
  });
  it('keeps an edit over a delete', () => {
    const a = clone(base), b = clone(base);
    a.expenses = a.expenses.filter(e => e.id !== 'e1');
    b.expenses.find(e => e.id === 'e1')!.amount = 2500;
    expect(mergeDocs(base, a, b).expenses.find(e => e.id === 'e1')!.amount).toBe(2500);
  });
  it('without a base (old phone) keeps both sides', () => {
    const U = mergeDocs(null, normalize(A), normalize(B));
    expect(['eA', 'eB'].every(id => U.expenses.some(e => e.id === id))).toBe(true);
  });
  it('two phones upgrading at once make no duplicate payments', () => {
    expect(mergeDocs(null, fresh(), fresh()).orders[0]!.payments).toHaveLength(1);
  });
  it('merges settings key by key', () => {
    const a = clone(base), b = clone(base); a.settings.currency = 'ETB'; b.settings.fcurrency = 'EUR';
    expect(mergeDocs(base, a, b).settings).toMatchObject({ currency: 'ETB', fcurrency: 'EUR', bagRate: 80 });
  });
});

describe('possible duplicates', () => {
  it('flags only same person, amount, day and note', () => {
    const D = normalize({ expenses: [
      { id: 'a', cat: 'Salaries', amount: 9000, date: '2026-11-01', scope: 'biz', employee: 'Almaz' },
      { id: 'b', cat: 'Salaries', amount: 9000, date: '2026-11-01', scope: 'biz', employee: 'Sara' },
      { id: 'c', cat: 'Salaries', amount: 9000, date: '2026-11-01', scope: 'biz', employee: 'Almaz' }] });
    expect([...duplicateIds(D)]).toEqual(['c']);
  });
});
