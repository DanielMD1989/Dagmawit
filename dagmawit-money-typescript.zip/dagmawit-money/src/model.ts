/* ============================================================
   model.ts — the business data: its shape on load, the one-time
   upgrade of older data, ALL money calculations, the "learning"
   suggestions, and the record-by-record merge used by sync.
   No DOM access (tested directly by the unit tests).

   Money rules (one place, used by every screen):
   • Income       = customer payments, on the day each was received.
   • Expenses     = work (business) or home (household) spending.
   • Profit       = income − work expenses.
   • Loans        = borrowed money ADDS to cash; repayments TAKE from
                    cash. Neither is income, expense or profit (only
                    interest is a cost — log it as an expense).
   • Assets       = big things bought (machine, car): take from cash,
                    not from profit (the value is still owned).
   • Cash in hand = income + borrowed − expenses − repaid − assets.
   • Website (foreign currency) orders are kept separate.
   ============================================================ */
import type { Category, Doc, Due, Expense, Flow, Id, Loan, MonthTotals, Order, OwedGroup, QuickPick, Scope, ScopeSuggestion, Totals, Ym, Ymd, Customer } from './types';
import { addDays, addMonths, clone, daysBetween, isObj, lower, monthRange, num, same, sameId, shiftYm, today, uid, words, ymOf } from './util';

export const SCHEMA = 2;
const COLLECTIONS = ['orders', 'expenses', 'loans', 'rolls', 'events', 'customers', 'assets'] as const;

export function emptyDoc(): Doc {
  return { schema: SCHEMA, orders: [], expenses: [], loans: [], rolls: [], events: [], customers: [], assets: [], settings: { currency: 'Birr', fcurrency: 'USD' } };
}

/** Makes any stored document safe to use and upgrades older data.
 *  Nothing is ever removed: unknown fields and planner data are kept. */
export function normalize(input: unknown): Doc {
  const d = (isObj(input) ? input : {}) as Record<string, unknown>;
  COLLECTIONS.forEach(k => { if (!Array.isArray(d[k])) d[k] = []; });
  if (!isObj(d.settings)) d.settings = {};
  const s = d.settings as Record<string, unknown>;
  if (!s.currency) s.currency = 'Birr';
  if (!s.fcurrency) s.fcurrency = 'USD';
  const doc = d as unknown as Doc;
  migrate(doc);
  return doc;
}

function legacyIncomeDate(o: Order): Ymd {
  // how the old app dated an order's money (used once, for the upgrade)
  if (o.payType === 'On delivery' && o.delivered && o.deliveredOn) return o.deliveredOn;
  return o.created || o.deliveredOn || today();
}

const asNum = (v: unknown): number => (typeof v === 'number' && Number.isFinite(v)) ? v : num(v);

function migrate(d: Doc): void {
  d.orders.forEach(o => {
    o.total = asNum(o.total);
    if (!Array.isArray(o.payments)) {
      // Upgrade: the old single "paid" total becomes the first payment. The id
      // comes from the order id, so two phones upgrading at the same time make
      // the identical record (no duplicates after merging).
      const paid = num(o.paid);
      o.payments = paid > 0 ? [{ id: 'm_' + o.id, amount: paid, date: legacyIncomeDate(o), note: 'Paid before payment history was kept' }] : [];
    } else {
      o.payments.forEach(p => { p.amount = asNum(p.amount); });
      // A phone still on the old version may have raised "paid" without adding
      // a payment: keep that money as a payment too.
      const gap = num(o.paid) - orderPaid(o);
      if (gap > 0.0001) o.payments.push({ id: 'r_' + o.id + '_' + Math.round(num(o.paid)), amount: gap, date: today(), note: 'Added from the older app version' });
    }
    o.paid = orderPaid(o);
  });
  d.expenses.forEach(e => { e.amount = asNum(e.amount); });
  d.assets.forEach(a => { a.value = asNum(a.value); });
  d.loans.forEach(l => {
    l.total = asNum(l.total);
    if (!l.received) {
      const first = d.expenses.filter(e => sameId(e.loanId, l.id) && e.date).map(e => e.date).sort()[0];
      l.received = l.created || first || today();
    }
  });
  d.schema = SCHEMA;
}

/* ---------- record helpers ---------- */
export const isForeign = (o: Order | undefined | null): boolean => !!o && o.currency === 'foreign';
export const isRepayment = (e: Expense | undefined | null): boolean => !!e && e.loanId != null && e.loanId !== '';
export const isHome = (e: { scope?: unknown } | undefined | null): boolean => !!e && e.scope === 'home';
export const scopeOf = (e: { scope?: unknown }): Scope => isHome(e) ? 'home' : 'biz';
export const scopeWord = (s: Scope): string => s === 'home' ? 'home' : 'work';
export function orderPaid(o: Order): number { return (o.payments || []).reduce((s, p) => s + num(p.amount), 0); }
export function orderLeft(o: Order): number { return Math.max(0, num(o.total) - orderPaid(o)); }
export function lastPaymentDate(o: Order): Ymd { return (o.payments || []).map(p => p.date).sort().pop() || ''; }
export function loanRepaid(d: Doc, l: Loan): number { return d.expenses.filter(e => sameId(e.loanId, l.id)).reduce((s, e) => s + num(e.amount), 0); }
export function loanLeft(d: Doc, l: Loan): number { return Math.max(0, num(l.total) - loanRepaid(d, l)); }

/** Every movement of money as one row. All totals come from here, so the
 *  home screen, reports and "check the numbers" always agree. */
export function moneyFlows(d: Doc): Flow[] {
  const rows: Flow[] = [];
  d.orders.forEach(o => (o.payments || []).forEach(p => rows.push({ kind: isForeign(o) ? 'fin' : 'in', date: p.date || '', amount: num(p.amount), order: o, pay: p })));
  d.expenses.forEach(e => rows.push({ kind: isRepayment(e) ? 'repay' : 'out', date: e.date || '', amount: num(e.amount), scope: scopeOf(e), exp: e }));
  d.loans.forEach(l => rows.push({ kind: 'loan', date: l.received || '', amount: num(l.total), loan: l }));
  d.assets.forEach(a => rows.push({ kind: 'asset', date: a.date || '', amount: num(a.value), asset: a }));
  return rows;
}

export function totals(d: Doc, from: Ymd | null, to: Ymd | null): Totals {
  let income = 0, work = 0, home = 0, repaid = 0, borrowed = 0, assets = 0, fIncome = 0;
  for (const r of moneyFlows(d)) {
    if (from && r.date < from) continue;
    if (to && r.date > to) continue;
    switch (r.kind) {
      case 'in': income += r.amount; break;
      case 'fin': fIncome += r.amount; break;
      case 'out': if (r.scope === 'home') home += r.amount; else work += r.amount; break;
      case 'repay': repaid += r.amount; break;
      case 'loan': borrowed += r.amount; break;
      case 'asset': assets += r.amount; break;
    }
  }
  const spent = work + home, cashIn = income + borrowed, cashOut = spent + repaid + assets;
  return { income, work, home, repaid, borrowed, assets, fIncome, spent, profit: income - work, cashIn, cashOut, net: cashIn - cashOut };
}
export function cashInHand(d: Doc): number { return totals(d, null, null).net; }

/** The last `count` months ending at endYm, each with the cash in hand at month end. */
export function monthSeries(d: Doc, count: number, endYm?: Ym): MonthTotals[] {
  const end = endYm || ymOf(today()), out: MonthTotals[] = [];
  for (let i = count - 1; i >= 0; i--) {
    const ym = shiftYm(end, -i), [from, to] = monthRange(ym);
    out.push({ ...totals(d, from, to), ym, cashEnd: totals(d, null, to).net });
  }
  return out;
}

/** Who owes: open local-currency orders grouped by customer, biggest first. */
export function owedByCustomer(d: Doc): OwedGroup[] {
  const map = new Map<string, OwedGroup>();
  d.orders.filter(o => !isForeign(o) && orderLeft(o) > 0).forEach(o => {
    const key = o.customerId != null && o.customerId !== '' ? String(o.customerId) : 'n:' + lower(o.customer || 'Unknown');
    let g = map.get(key);
    if (!g) { g = { key, name: o.customer || 'Unknown', phone: '', left: 0, orders: [], oldest: '' }; map.set(key, g); }
    g.left += orderLeft(o); g.orders.push(o);
    if (!g.phone && o.phone) g.phone = o.phone;
  });
  const groups = [...map.values()];
  groups.forEach(g => {
    if (!g.phone) { const c = d.customers.find(c => String(c.id) === g.key); if (c && c.phone) g.phone = c.phone; }
    g.orders.sort((a, b) => String(a.created || '').localeCompare(String(b.created || '')));
    g.oldest = g.orders[0]?.created || '';
  });
  return groups.sort((a, b) => b.left - a.left);
}
export function totalOwed(d: Doc): number { return d.orders.filter(o => !isForeign(o)).reduce((s, o) => s + orderLeft(o), 0); }
export function totalOwedForeign(d: Doc): number { return d.orders.filter(isForeign).reduce((s, o) => s + orderLeft(o), 0); }

/** Repeating costs: next due date from the latest entry of each kind. */
export function recurringDue(d: Doc, withinDays: number): Due[] {
  const latest = new Map<string, Expense>();
  d.expenses.filter(e => e.recurring && !isRepayment(e) && e.date).forEach(e => {
    const k = [e.cat, scopeOf(e), lower(e.employee), lower(e.note)].join('|');
    const cur = latest.get(k);
    if (!cur || e.date > cur.date) latest.set(k, e);
  });
  const t = today();
  return [...latest.values()].map(e => {
    const next = e.freq === 'week' ? addDays(e.date, 7) : addMonths(e.date, e.freq === 'quarter' ? 3 : 1);
    return { exp: e, next, days: daysBetween(t, next) };
  }).filter(x => x.days <= withinDays).sort((a, b) => a.days - b.days);
}

/** Possible duplicates: same kind, amount, day, person and note. */
export function duplicateIds(d: Doc): Set<string> {
  const seen = new Set<string>(), dups = new Set<string>();
  d.expenses.filter(e => !isRepayment(e) && e.rollId == null).slice().sort((a, b) => String(a.id).localeCompare(String(b.id))).forEach(e => {
    const k = [scopeOf(e), e.cat, num(e.amount), e.date, lower(e.employee), lower(e.note)].join('|');
    if (seen.has(k)) dups.add(String(e.id)); else seen.add(k);
  });
  return dups;
}

/* ---------- customers (saved records are protected: never overwritten) ---------- */
export function findCustomerByName(d: Doc, name: string): Customer | undefined { const n = lower(name); return n ? d.customers.find(c => lower(c.name) === n) : undefined; }
export function ensureCustomer(d: Doc, name: string, phone: string): Id {
  let c = findCustomerByName(d, name);
  if (!c) { c = { id: uid(), name: name.trim(), phone: phone || '', m: {} }; d.customers.push(c); }
  else if (phone && !c.phone) c.phone = phone;
  return c.id;
}
export function ordersForCustomer(d: Doc, c: Customer): Order[] {
  const n = lower(c.name);
  return d.orders.filter(o => (o.customerId != null && o.customerId !== '' ? sameId(o.customerId, c.id) : lower(o.customer) === n));
}

/* ============================================================
   LEARNING — suggestions from her own history (on the phone, no
   AI service): work or home, the category, and frequent entries.
   ============================================================ */
export const CATEGORIES: Category[] = [
  { k: 'Fabric', ic: 'needle-thread', def: 'biz' },
  { k: 'Accessories', ic: 'scissors', def: 'biz' },
  { k: 'Salaries', ic: 'users', def: 'biz' },
  { k: 'Transport', ic: 'truck', def: null },
  { k: 'Fuel', ic: 'gas-station', def: null },
  { k: 'Rent', ic: 'home-dollar', def: null },
  { k: 'Bazar', ic: 'building-store', def: 'biz' },
  { k: 'Shipment', ic: 'package', def: 'biz' },
  { k: 'Grocery', ic: 'shopping-cart', def: 'home' },
  { k: 'School', ic: 'school', def: 'home' },
  { k: 'Other', ic: 'dots', def: null }
];

export function suggestScope(d: Doc, cat: string, note: string, employee: string): ScopeSuggestion {
  const hist = d.expenses.filter(e => !isRepayment(e) && e.cat === cat);
  const catWords = words(cat);
  // the category's own name ("rent" in "shop rent") tells nothing — ignore it
  const nw = words(note).filter(w => !catWords.includes(w)), emp = lower(employee);
  const score = (e: Expense): number => (emp && lower(e.employee) === emp ? 10 : 0) + words(e.note).filter(w => nw.includes(w)).length;
  const best = hist.reduce((m, e) => Math.max(m, score(e)), 0);
  const similar = best > 0 ? hist.filter(e => score(e) === best) : [];   // closest matches only
  const pick = (list: Expense[], what: string): ScopeSuggestion => {
    const home = list.filter(isHome).length, biz = list.length - home, scope: Scope = home > biz ? 'home' : 'biz';
    return { scope, learned: true, text: Math.max(home, biz) + ' of ' + list.length + ' ' + what + ' were ' + scopeWord(scope) };
  };
  if (similar.length) return pick(similar, 'similar ' + cat + ' entries');
  if (hist.length) return pick(hist, 'past ' + cat + ' entries');
  const c = CATEGORIES.find(x => x.k === cat);
  if (c && c.def) return { scope: c.def, learned: false, text: cat + ' is usually ' + scopeWord(c.def) };
  return { scope: 'biz', learned: false, text: 'Pick one; the app learns from your choice' };
}

export function suggestCategory(d: Doc, note: string): string | null {
  const nw = words(note); if (!nw.length) return null;
  const count = new Map<string, number>();
  d.expenses.filter(e => !isRepayment(e) && words(e.note).some(w => nw.includes(w))).forEach(e => count.set(e.cat, (count.get(e.cat) || 0) + 1));
  const best = [...count.entries()].sort((a, b) => b[1] - a[1])[0];
  return best ? best[0] : null;
}

/** Her most frequent recent entries (last ~4 months), as one-tap picks. */
export function quickPicks(d: Doc, max = 4): QuickPick[] {
  const since = addDays(today(), -120), g = new Map<string, QuickPick>();
  d.expenses.filter(e => !isRepayment(e) && e.rollId == null && e.date >= since).forEach(e => {
    const k = [e.cat, scopeOf(e), lower(e.note), lower(e.employee)].join('|');
    let x = g.get(k);
    if (!x) { x = { cat: e.cat, scope: scopeOf(e), note: e.note || '', employee: e.employee || '', count: 0, last: '', amount: 0, recurring: false, freq: 'once' }; g.set(k, x); }
    x.count++;
    if (e.date >= x.last) { x.last = e.date; x.amount = num(e.amount); x.recurring = !!e.recurring; x.freq = String(e.freq || 'once'); }
  });
  return [...g.values()].filter(x => x.count >= 2).sort((a, b) => (b.count - a.count) || b.last.localeCompare(a.last)).slice(0, max);
}

/* ============================================================
   MERGE — combines two phones' changes record by record.
   base   = the version both phones last agreed on
   local  = this phone's version, remote = the database's version
   A record changed on one side only takes that side's version.
   Changed on both: field by field; this phone wins only for fields
   that both changed. Edited on one side and deleted on the other:
   the edit is kept (nothing is lost silently).
   ============================================================ */
type Rec = Record<string, unknown> & { id: Id };
const isIdList = (v: unknown): v is Rec[] => Array.isArray(v) && v.every(x => isObj(x) && x.id != null);

export function mergeDocs(base: Doc | null, local: Doc, remote: Doc): Doc {
  const b = (base || {}) as Record<string, unknown>, l = local as Record<string, unknown>, r = remote as Record<string, unknown>;
  const out: Record<string, unknown> = {};
  new Set([...Object.keys(r), ...Object.keys(l)]).forEach(k => {
    const v = mergeValue(b[k], l[k], r[k]);
    if (v !== undefined) out[k] = v;
  });
  // "paid" is only a copy of the payments total: recompute it from the merged
  // payments so it can never disagree with them.
  const orders = out.orders;
  if (Array.isArray(orders)) orders.forEach(o => { if (isObj(o) && Array.isArray(o.payments)) o.paid = orderPaid(o as unknown as Order); });
  return normalize(out);
}

function mergeValue(b: unknown, l: unknown, r: unknown): unknown {
  if (same(l, b)) return clone(r);
  if (same(r, b)) return clone(l);
  if (same(l, r)) return clone(l);
  // both sides changed it
  if ((l === undefined || isIdList(l)) && (r === undefined || isIdList(r)) && (b === undefined || isIdList(b)))
    return mergeList(isIdList(b) ? b : [], isIdList(l) ? l : [], isIdList(r) ? r : []);
  if (isObj(l) && isObj(r)) return mergeObject(isObj(b) ? b : {}, l, r);
  return clone(l === undefined ? r : l);
}

function mergeObject(b: Record<string, unknown>, l: Record<string, unknown>, r: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  new Set([...Object.keys(r), ...Object.keys(l)]).forEach(k => {
    const v = mergeValue(b[k], l[k], r[k]);
    if (v !== undefined) out[k] = v;
  });
  return out;
}

function mergeList(b: Rec[], l: Rec[], r: Rec[]): Rec[] {
  const B = new Map(b.map(x => [String(x.id), x])), L = new Map(l.map(x => [String(x.id), x])), R = new Map(r.map(x => [String(x.id), x]));
  const order = r.map(x => String(x.id));
  l.forEach(x => { if (!R.has(String(x.id))) order.push(String(x.id)); });
  const out: Rec[] = [];
  for (const id of order) {
    const bx = B.get(id), lx = L.get(id), rx = R.get(id);
    let v: unknown;
    if (!bx) v = lx && rx ? mergeValue(undefined, lx, rx) : clone(lx || rx);   // added
    else if (!lx && !rx) v = undefined;                                         // deleted on both
    else if (!lx) v = same(rx, bx) ? undefined : clone(rx);                     // deleted here, kept if edited there
    else if (!rx) v = same(lx, bx) ? undefined : clone(lx);                     // deleted there, kept if edited here
    else v = mergeValue(bx, lx, rx);
    if (v !== undefined) out.push(v as Rec);
  }
  return out;
}
