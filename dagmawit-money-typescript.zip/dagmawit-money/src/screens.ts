/* ============================================================
   screens.ts — the pages (Home, Orders, Expenses, Reports and the
   side-menu pages). Pages only READ data; every change happens in a
   sheet (forms.ts).
   ============================================================ */
import type { Expense, Flow, Order, Ym } from './types';
import { ACT, INPUT, PAGES } from './registry';
import { icon } from './icons';
import { db } from './sync';
import { esc, monthLabel, monthRange, niceDate, num, shiftYm, today, ymOf, lower } from './util';
import {
  CUR, FCUR, UI, catIcon, emptyBox, figure, go, money, render, rerenderKeepingFocus, signed
} from './ui';
import {
  duplicateIds, isForeign, isHome, isRepayment, lastPaymentDate, loanLeft, moneyFlows, monthSeries,
  orderLeft, orderPaid, ordersForCustomer, owedByCustomer, recurringDue, totalOwed, totalOwedForeign, totals
} from './model';

/* ---------- shared row renderers ---------- */
export function expenseRow(e: Expense, isDup: boolean): string {
  const home = isHome(e);
  return '<button class="row" data-act="editExpense" data-id="' + esc(e.id) + '"><div class="av ' + (home ? 'home' : 'out') + '">' + icon(catIcon(e.cat)) + '</div><div class="body"><div class="t1">' + esc(e.cat || 'Expense') + (e.employee ? ' · ' + esc(e.employee) : '') + '</div><div class="t2">' + (home ? 'Home' : 'Work') + (e.note ? ' · ' + esc(e.note) : '') + ' · ' + niceDate(e.date) + '</div>'
    + (isDup ? '<span class="tag warn">Possible duplicate</span>' : '') + '</div><div class="end"><div class="amt out">−' + money(e.amount) + '</div></div></button>';
}

export function flowRow(r: Flow): string {
  switch (r.kind) {
    case 'in': case 'fin': {
      const o = r.order, cur = r.kind === 'fin' ? FCUR() : CUR();
      return '<button class="row" data-act="openOrder" data-id="' + esc(o.id) + '"><div class="av in">' + icon('cash') + '</div><div class="body"><div class="t1">' + esc(o.customer || 'Customer') + '</div><div class="t2">Payment' + (o.clothType ? ' · ' + esc(o.clothType) : '') + ' · ' + niceDate(r.date) + '</div></div><div class="end"><div class="amt in">+' + money(r.amount, cur) + '</div></div></button>';
    }
    case 'out': return expenseRow(r.exp, false);
    case 'repay': {
      const l = db().loans.find(x => String(x.id) === String(r.exp.loanId));
      return '<button class="row" data-act="openLoan" data-id="' + esc(r.exp.loanId) + '"><div class="av loan">' + icon('building-bank') + '</div><div class="body"><div class="t1">Loan repayment' + (l ? ' · ' + esc(l.lender) : '') + '</div><div class="t2">Not an expense · ' + niceDate(r.date) + '</div></div><div class="end"><div class="amt loan">−' + money(r.amount) + '</div></div></button>';
    }
    case 'loan':
      return '<button class="row" data-act="openLoan" data-id="' + esc(r.loan.id) + '"><div class="av loan">' + icon('building-bank') + '</div><div class="body"><div class="t1">Borrowed · ' + esc(r.loan.lender || 'Loan') + '</div><div class="t2">Not income · ' + niceDate(r.date) + '</div></div><div class="end"><div class="amt loan">+' + money(r.amount) + '</div></div></button>';
    case 'asset':
      return '<button class="row" data-act="editAsset" data-id="' + esc(r.asset.id) + '"><div class="av">' + icon('building-factory-2') + '</div><div class="body"><div class="t1">' + esc(r.asset.name || 'Asset') + '</div><div class="t2">Asset bought · ' + niceDate(r.date) + '</div></div><div class="end"><div class="amt out">−' + money(r.amount) + '</div></div></button>';
  }
}
const byDateDesc = (a: { date: string }, b: { date: string }): number => (b.date || '').localeCompare(a.date || '');

export function orderRow(o: Order): string {
  const fx = isForeign(o), cur = fx ? FCUR() : CUR(), left = orderLeft(o), paid = orderPaid(o), pct = o.total > 0 ? Math.min(100, Math.round(paid / o.total * 100)) : 0;
  const what = [o.orderType === 'bazar' ? 'Bazar' : '', fx ? 'Website' : '', o.clothType || ''].filter(Boolean).join(' · ');
  const sub = (what ? what + ' · ' : '') + (left > 0 ? 'ordered ' + niceDate(o.created) : 'paid ' + niceDate(lastPaymentDate(o)));
  const end = left > 0
    ? '<div class="amt out">' + money(left, cur) + '</div><div class="sub">left of ' + money(o.total, cur) + '</div>'
    : '<div class="amt in">' + money(o.total, cur) + '</div><div class="sub">paid</div>';
  return '<button class="row" data-act="openOrder" data-id="' + esc(o.id) + '"><div class="body"><div class="t1">' + esc(o.customer || 'Customer') + '</div><div class="t2">' + esc(sub) + '</div>'
    + (left > 0 ? '<div class="bar"><i style="width:' + pct + '%"></i></div>' : '') + '</div><div class="end">' + end + '</div></button>';
}

function monthSwitch(ym: Ym, act: string): string {
  return '<div class="monthsw"><button data-act="' + act + '" data-d="-1" aria-label="Previous month">' + icon('chevron-left') + '</button><b>' + monthLabel(ym) + '</b><button data-act="' + act + '" data-d="1" aria-label="Next month"' + (ym >= ymOf(today()) ? ' disabled' : '') + '>' + icon('chevron-right') + '</button></div>';
}
const plural = (n: number, w: string): string => n + ' ' + w + (n === 1 ? '' : 's');

/* ============================================================ HOME */
PAGES.home = {
  title: 'Home', render() {
    const d = db(), ym = ymOf(today()), [from, to] = monthRange(ym), m = totals(d, from, to), all = totals(d, null, null);
    let h = '<div class="hero"><div class="k">Cash in hand</div><div class="v">' + signed(all.net) + '</div>'
      + '<div class="strip"><div><div class="sk">In · ' + monthLabel(ym, true) + '</div><div class="sv">' + figure(m.income) + '</div></div>'
      + '<div><div class="sk">Spent</div><div class="sv">' + figure(m.spent) + '</div></div>'
      + '<div><div class="sk">Profit</div><div class="sv">' + figure(m.profit) + '</div></div></div>'
      + (all.fIncome > 0 ? '<div class="foot">+ ' + money(all.fIncome, FCUR()) + ' from website orders, kept separate</div>' : '') + '</div>';
    h += '<div class="quick"><button data-act="gotPaid">' + icon('cash') + 'Got paid</button><button data-act="spent">' + icon('receipt-2') + 'Spent</button><button data-act="newOrder">' + icon('plus') + 'New order</button></div>';

    const owed = owedByCustomer(d), totalO = owed.reduce((s, g) => s + g.left, 0);
    h += '<div class="sec"><h2>Owed to you · ' + money(totalO) + '</h2>' + (owed.length > 3 ? '<button class="link" data-act="whoOwes">See all ' + owed.length + '</button>' : '') + '</div>';
    h += '<div class="card">' + (owed.length ? owed.slice(0, 3).map(g => '<div class="row"><div class="body"><div class="t1">' + esc(g.name) + '</div><div class="t2">' + plural(g.orders.length, 'order') + ' · since ' + niceDate(g.oldest) + '</div></div><div class="end"><div class="amt out">' + money(g.left) + '</div></div><button class="pillbtn" data-act="payCustomer" data-key="' + esc(g.key) + '">Record</button></div>').join('') : emptyBox('check', 'Nobody owes you right now.')) + '</div>';

    const due = recurringDue(d, 14), loans = d.loans.filter(l => loanLeft(d, l) > 0);
    if (due.length || loans.length) {
      h += '<div class="sec"><h2>Coming up</h2></div><div class="card">';
      h += due.map(x => {
        const e = x.exp, when = x.days < 0 ? 'overdue ' + plural(-x.days, 'day') : x.days === 0 ? 'due today' : 'in ' + plural(x.days, 'day');
        return '<button class="row" data-act="repeatExpense" data-id="' + esc(e.id) + '"><div class="av ' + (isHome(e) ? 'home' : 'out') + '">' + icon('calendar-repeat') + '</div><div class="body"><div class="t1">' + esc(e.cat) + (e.employee ? ' · ' + esc(e.employee) : '') + '</div><div class="t2">' + (x.days < 0 ? '<span style="color:var(--out);font-weight:600">' + when + '</span>' : when) + ' · tap to log it</div></div><div class="end"><div class="amt muted">' + money(e.amount) + '</div></div></button>';
      }).join('');
      h += loans.map(l => {
        const left = loanLeft(d, l), pct = l.total > 0 ? Math.round((l.total - left) / l.total * 100) : 0;
        return '<button class="row" data-act="openLoan" data-id="' + esc(l.id) + '"><div class="av loan">' + icon('building-bank') + '</div><div class="body"><div class="t1">' + esc(l.lender || 'Loan') + '</div><div class="t2">' + pct + '% repaid</div><div class="bar"><i style="width:' + pct + '%;background:var(--loan)"></i></div></div><div class="end"><div class="amt loan">' + money(left) + '</div><div class="sub">left</div></div></button>';
      }).join('');
      h += '</div>';
    }
    const recent = moneyFlows(d).filter(r => r.date).sort(byDateDesc).slice(0, 8);
    h += '<div class="sec"><h2>Recent</h2></div><div class="card">' + (recent.length ? recent.map(flowRow).join('') : emptyBox('cash', 'Nothing yet. Tap Got paid or Spent to start.')) + '</div>';
    return h;
  }
};

/* ============================================================ ORDERS */
PAGES.orders = {
  title: 'Orders', render() {
    const d = db(), q = lower(UI.orders.q), f = UI.orders.filter;
    const match = (o: Order): boolean => !q || [o.customer, o.clothType, o.phone].some(v => lower(v).includes(q));
    const all = d.orders.filter(match);
    const owes = all.filter(o => orderLeft(o) > 0), paid = all.filter(o => orderLeft(o) <= 0);
    let h = '<div class="stats"><button class="stat" data-act="whoOwes"><div class="sk">Owed to you</div><div class="sv" style="color:var(--out)">' + money(totalOwed(d)) + '</div>' + (totalOwedForeign(d) > 0 ? '<div class="sx">+ ' + money(totalOwedForeign(d), FCUR()) + '</div>' : '<div class="sx">See who owes</div>') + '</button>'
      + '<div class="stat"><div class="sk">Orders this month</div><div class="sv">' + d.orders.filter(o => ymOf(o.created) === ymOf(today())).length + '</div><div class="sx">' + d.orders.length + ' in total</div></div></div>';
    const chips: [typeof f, string, number][] = [['owes', 'Owes', owes.length], ['paid', 'Paid', paid.length], ['all', 'All', all.length]];
    h += '<div class="chips" style="margin-top:12px">' + chips.map(c => '<button class="chip' + (f === c[0] ? ' on' : '') + '" data-act="ordFilter" data-f="' + c[0] + '">' + c[1] + '<span class="n">' + c[2] + '</span></button>').join('') + '</div>';
    h += '<div class="search">' + icon('search') + '<input id="ordQ" data-input="ordQ" placeholder="Search name, item or phone" value="' + esc(UI.orders.q) + '"></div>';
    if (f === 'owes') {
      const list = owes.sort((a, b) => String(a.created || '').localeCompare(String(b.created || '')));   // oldest debt first
      h += list.length ? '<div class="card">' + list.map(orderRow).join('') + '</div><p class="note">Oldest first.</p>' : '<div class="card">' + emptyBox('check', q ? 'No unpaid order matches.' : 'Everything is collected.') + '</div>';
    } else if (f === 'paid') {
      const groups = new Map<string, Order[]>();
      paid.forEach(o => { const ym = ymOf(lastPaymentDate(o) || o.created) || 'none'; groups.set(ym, [...(groups.get(ym) || []), o]); });
      const yms = [...groups.keys()].sort().reverse();
      h += yms.length ? '<div class="card">' + yms.map(ym => {
        const g = (groups.get(ym) || []).sort((a, b) => lastPaymentDate(b).localeCompare(lastPaymentDate(a)));
        return '<div class="group-h">' + (ym === 'none' ? 'No date' : monthLabel(ym)) + '<span>' + g.length + ' · ' + money(g.filter(o => !isForeign(o)).reduce((s, o) => s + o.total, 0)) + '</span></div>' + g.map(orderRow).join('');
      }).join('') + '</div>' : '<div class="card">' + emptyBox('receipt-2', 'No fully paid orders yet.') + '</div>';
    } else {
      const list = all.sort((a, b) => String(b.created || '').localeCompare(String(a.created || '')));
      h += list.length ? '<div class="card">' + list.map(orderRow).join('') + '</div>' : '<div class="card">' + emptyBox('receipt-2', q ? 'No order matches.' : 'No orders yet. Tap + to add one.') + '</div>';
    }
    return h;
  }
};
ACT.ordFilter = el => { UI.orders.filter = el.dataset.f as typeof UI.orders.filter; render(); };
INPUT.ordQ = el => { UI.orders.q = el.value; rerenderKeepingFocus('ordQ'); };

/* ============================================================ EXPENSES */
PAGES.expenses = {
  title: 'Expenses', render() {
    const d = db(), ym = UI.exp.ym || ymOf(today()), f = UI.exp.filter, q = lower(UI.exp.q), [from, to] = monthRange(ym), m = totals(d, from, to);
    let h = monthSwitch(ym, 'expMonth');
    h += '<div class="stats three"><div class="stat"><div class="sk">Work · ' + esc(CUR()) + '</div><div class="sv" style="color:var(--out)">' + figure(m.work) + '</div></div><div class="stat"><div class="sk">Home · ' + esc(CUR()) + '</div><div class="sv" style="color:var(--warn)">' + figure(m.home) + '</div></div><div class="stat"><div class="sk">Total · ' + esc(CUR()) + '</div><div class="sv">' + figure(m.spent) + '</div></div></div>';
    const chips: [typeof f, string][] = [['all', 'All'], ['biz', 'Work'], ['home', 'Home']];
    h += '<div class="chips" style="margin-top:12px">' + chips.map(c => '<button class="chip' + (f === c[0] ? ' on' : '') + '" data-act="expFilter" data-f="' + c[0] + '">' + c[1] + '</button>').join('')
      + (UI.exp.cat ? '<button class="chip on" data-act="expClearCat">' + esc(UI.exp.cat) + ' ×</button>' : '') + '</div>';
    h += '<div class="search">' + icon('search') + '<input id="expQ" data-input="expQ" placeholder="Search all months: category, note, person" value="' + esc(UI.exp.q) + '"></div>';
    let list = d.expenses.filter(e => !isRepayment(e) && e.rollId == null && (f === 'all' || (f === 'home') === isHome(e)) && (!UI.exp.cat || e.cat === UI.exp.cat));
    list = q ? list.filter(e => [e.cat, e.note, e.employee].some(v => lower(v).includes(q))) : list.filter(e => ymOf(e.date) === ym);
    list.sort((a, b) => (b.date || '').localeCompare(a.date || '') || String(b.id).localeCompare(String(a.id)));
    const dups = duplicateIds(d), nd = list.filter(e => dups.has(String(e.id))).length;
    if (nd) h += '<div class="card pad" style="background:var(--warn-soft);border-color:transparent;margin-bottom:12px"><b>' + plural(nd, 'possible duplicate') + '</b>: same thing, amount, person and day. Tap one to check it.</div>';
    if (q) h += '<p class="note" style="margin:0 4px 8px">' + plural(list.length, 'result') + ' in all months</p>';
    h += '<div class="card">' + (list.length ? list.map(e => expenseRow(e, dups.has(String(e.id)))).join('') : emptyBox('receipt-2', q ? 'Nothing matches.' : 'No expenses in ' + monthLabel(ym) + '.')) + '</div>';
    if (!q && d.expenses.some(e => isRepayment(e) && ymOf(e.date) === ym)) h += '<p class="note">Loan repayments are under Loans: they return borrowed money, so they are not counted as expenses.</p>';
    return h;
  }
};
ACT.expMonth = el => { UI.exp.ym = shiftYm(UI.exp.ym || ymOf(today()), Number(el.dataset.d)); render(); };
ACT.expFilter = el => { UI.exp.filter = el.dataset.f as typeof UI.exp.filter; render(); };
ACT.expClearCat = () => { UI.exp.cat = null; render(); };
INPUT.expQ = el => { UI.exp.q = el.value; rerenderKeepingFocus('expQ'); };

/* ============================================================ REPORTS */
PAGES.reports = {
  title: 'Reports', render() {
    const d = db(), ym = UI.rep.ym || ymOf(today()), [from, to] = monthRange(ym), m = totals(d, from, to);
    const series = monthSeries(d, 6, ym), cashEnd = series[series.length - 1]?.cashEnd ?? 0;
    let h = monthSwitch(ym, 'repMonth');
    h += '<div class="stats three"><div class="stat"><div class="sk">In · ' + esc(CUR()) + '</div><div class="sv" style="color:var(--in)">' + figure(m.income) + '</div></div><div class="stat"><div class="sk">Spent · ' + esc(CUR()) + '</div><div class="sv" style="color:var(--out)">' + figure(m.spent) + '</div></div><div class="stat"><div class="sk">Profit · ' + esc(CUR()) + '</div><div class="sv" style="color:' + (m.profit >= 0 ? 'var(--main)' : 'var(--out)') + '">' + figure(m.profit) + '</div></div></div>';
    h += '<p class="note">Profit = money in − work expenses. Home spending lowers your cash, not the business profit.</p>';
    const max = Math.max(1, ...series.map(s => Math.max(s.income, s.spent)));
    h += '<div class="sec"><h2>Last 6 months</h2></div><div class="card pad">'
      + (UI.hideMoney ? emptyBox('eye-off', 'Amounts are hidden.') : '<div class="mchart">' + series.map(s => '<button class="mcol' + (s.ym === ym ? ' sel' : '') + '" data-act="repPick" data-ym="' + s.ym + '" aria-label="' + monthLabel(s.ym) + '"><div class="mbars"><i class="i" style="height:' + Math.round(s.income / max * 100) + '%"></i><i class="o" style="height:' + Math.round(s.spent / max * 100) + '%"></i></div><div class="ml">' + monthLabel(s.ym, true) + '</div></button>').join('') + '</div><div class="legend"><span><i style="background:var(--in)"></i>Money in</span><span><i style="background:var(--out)"></i>Spent</span></div>')
      + '</div>';
    const cats = (scope: 'biz' | 'home'): [string, number][] => {
      const c = new Map<string, number>();
      d.expenses.filter(e => !isRepayment(e) && ymOf(e.date) === ym && (scope === 'home') === isHome(e)).forEach(e => c.set(e.cat, (c.get(e.cat) || 0) + num(e.amount)));
      return [...c.entries()].sort((a, b) => b[1] - a[1]);
    };
    const bars = (list: [string, number][], color: string, scope: 'biz' | 'home'): string => {
      const mx = Math.max(1, ...list.map(x => x[1]));
      return list.map(x => '<button class="hbar" data-act="repCat" data-cat="' + esc(x[0]) + '" data-scope="' + scope + '"><span class="hn">' + esc(x[0]) + '</span><span class="ht"><i style="width:' + Math.round(x[1] / mx * 100) + '%;background:' + color + '"></i></span><span class="hv">' + money(x[1]) + '</span></button>').join('');
    };
    const w = cats('biz'), hm = cats('home');
    h += '<div class="sec"><h2>Work spending · ' + money(m.work) + '</h2></div><div class="card" style="padding:6px 0">' + (w.length ? bars(w, 'var(--out)', 'biz') : emptyBox('receipt-2', 'No work expenses this month.')) + '</div>';
    h += '<div class="sec"><h2>Home spending · ' + money(m.home) + '</h2></div><div class="card" style="padding:6px 0">' + (hm.length ? bars(hm, 'var(--warn)', 'home') : emptyBox('home', 'No home expenses this month.')) + '</div>';
    h += '<div class="sec"><h2>Cash this month</h2></div><div class="card">'
      + '<div class="kv"><span>Cash at start</span><b>' + signed(cashEnd - m.net) + '</b></div>'
      + '<div class="kv"><span>+ Money in</span><b style="color:var(--in)">' + money(m.income) + '</b></div>'
      + (m.borrowed ? '<div class="kv"><span>+ Borrowed</span><b style="color:var(--loan)">' + money(m.borrowed) + '</b></div>' : '')
      + '<div class="kv"><span>− Spent (work + home)</span><b style="color:var(--out)">' + money(m.spent) + '</b></div>'
      + (m.repaid ? '<div class="kv"><span>− Loan repaid</span><b style="color:var(--loan)">' + money(m.repaid) + '</b></div>' : '')
      + (m.assets ? '<div class="kv"><span>− Assets bought</span><b>' + money(m.assets) + '</b></div>' : '')
      + '<div class="kv"><span><b style="color:var(--ink)">Cash at end</b></span><b>' + signed(cashEnd) + '</b></div>'
      + (m.fIncome ? '<div class="kv"><span>Website orders (separate)</span><b>' + money(m.fIncome, FCUR()) + '</b></div>' : '')
      + '</div>';
    h += '<button class="btn line" data-act="go" data-tab="audit">' + icon('calculator') + 'Check the numbers</button>';
    return h;
  }
};
ACT.repMonth = el => { UI.rep.ym = shiftYm(UI.rep.ym || ymOf(today()), Number(el.dataset.d)); render(); };
ACT.repPick = el => { UI.rep.ym = el.dataset.ym || null; render(); };
ACT.repCat = el => { UI.exp.ym = UI.rep.ym || ymOf(today()); UI.exp.filter = el.dataset.scope === 'home' ? 'home' : 'biz'; UI.exp.cat = el.dataset.cat || null; UI.exp.q = ''; go('expenses'); };

/* ============================================================ CHECK THE NUMBERS */
PAGES.audit = {
  title: 'Check the numbers', render() {
    const d = db(), ym = UI.rep.ym || ymOf(today()), [from, to] = monthRange(ym), m = totals(d, from, to);
    const rows = moneyFlows(d).filter(x => x.date >= from && x.date <= to).sort(byDateDesc);
    const part = (title: string, keep: (f: Flow) => boolean, sum: number, color: string): string => {
      const list = rows.filter(keep);
      return '<div class="sec"><h2>' + title + '</h2><b style="color:' + color + '">' + money(sum) + '</b></div><div class="card">' + (list.length ? list.map(flowRow).join('') : emptyBox('check', 'None this month.')) + '</div>';
    };
    let h = monthSwitch(ym, 'repMonth');
    h += '<p class="note" style="margin-bottom:6px">Every amount counted in ' + monthLabel(ym) + ', on the day the money moved. If a number looks wrong, open it and check its date.</p>';
    h += part('Money in (customer payments)', x => x.kind === 'in', m.income, 'var(--in)');
    h += part('Work expenses', x => x.kind === 'out' && x.scope === 'biz', m.work, 'var(--out)');
    h += part('Home expenses', x => x.kind === 'out' && x.scope === 'home', m.home, 'var(--warn)');
    if (m.borrowed || m.repaid) h += part('Loans (not income, not expense)', x => x.kind === 'loan' || x.kind === 'repay', m.borrowed - m.repaid, 'var(--loan)');
    if (m.assets) h += part('Assets bought', x => x.kind === 'asset', m.assets, 'var(--ink)');
    if (m.fIncome) h += part('Website orders (' + esc(FCUR()) + ', separate)', x => x.kind === 'fin', m.fIncome, 'var(--in)');
    h += '<div class="card" style="margin-top:16px"><div class="kv"><span>Profit = ' + money(m.income) + ' − ' + money(m.work) + '</span><b>' + signed(m.profit) + '</b></div><div class="kv"><span>Cash change this month</span><b>' + signed(m.net) + '</b></div></div>';
    return h;
  }
};

/* ============================================================ CUSTOMERS (view only) */
PAGES.customers = {
  title: 'Customers', render() {
    const d = db(), q = lower(UI.custQ);
    const list = d.customers.filter(c => !q || lower(c.name).includes(q) || String(c.phone || '').includes(q)).sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
    let h = '<p class="note" style="margin:-6px 4px 12px">View only. Contacts and measurements are kept safe here; update them in the planner app.</p>';
    h += '<div class="search">' + icon('search') + '<input id="custQ" data-input="custQ" placeholder="Search name or phone" value="' + esc(UI.custQ) + '"></div>';
    h += '<div class="card">' + (list.length ? list.map(c => {
      const n = ordersForCustomer(d, c).length, mm = Object.values(c.m || {}).filter(v => v !== '' && v != null).length;
      return '<button class="row" data-act="openCustomer" data-id="' + esc(c.id) + '"><div class="av">' + icon('users') + '</div><div class="body"><div class="t1">' + esc(c.name || 'Customer') + '</div><div class="t2">' + [c.phone || '', mm ? mm + ' measurements' : '', n ? plural(n, 'order') : ''].filter(Boolean).map(esc).join(' · ') + '</div></div>' + icon('chevron-right') + '</button>';
    }).join('') : emptyBox('users', q ? 'No customer matches.' : 'No customers saved.')) + '</div>';
    h += '<button class="btn line" data-act="customersCsv">' + icon('file-spreadsheet') + 'Download all customers (CSV)</button>';
    return h;
  }
};
INPUT.custQ = el => { UI.custQ = el.value; rerenderKeepingFocus('custQ'); };

/* ============================================================ LOANS */
PAGES.loans = {
  title: 'Loans', render() {
    const d = db(), loans = d.loans.slice().sort((a, b) => loanLeft(d, b) - loanLeft(d, a));
    const left = loans.reduce((s, l) => s + loanLeft(d, l), 0), borrowed = loans.reduce((s, l) => s + num(l.total), 0);
    let h = '<div class="stats"><div class="stat"><div class="sk">Still to repay</div><div class="sv" style="color:var(--loan)">' + money(left) + '</div></div><div class="stat"><div class="sk">Borrowed in total</div><div class="sv">' + money(borrowed) + '</div></div></div>';
    h += '<div class="card" style="margin-top:12px">' + (loans.length ? loans.map(l => {
      const lf = loanLeft(d, l), pct = l.total > 0 ? Math.round((l.total - lf) / l.total * 100) : 0;
      return '<button class="row" data-act="openLoan" data-id="' + esc(l.id) + '"><div class="av loan">' + icon('building-bank') + '</div><div class="body"><div class="t1">' + esc(l.lender || 'Loan') + '</div><div class="t2">' + money(num(l.total) - lf) + ' repaid of ' + money(l.total) + '</div><div class="bar"><i style="width:' + pct + '%;background:var(--loan)"></i></div></div><div class="end">' + (lf > 0 ? '<div class="amt loan">' + money(lf) + '</div><div class="sub">left</div>' : '<span class="tag in">Cleared</span>') + '</div></button>';
    }).join('') : emptyBox('building-bank', 'No loans.')) + '</div>';
    h += '<button class="btn" data-act="newLoan">' + icon('plus') + 'Add a loan</button>';
    h += '<p class="note">Borrowed money adds to cash in hand; repayments take from it. Neither changes profit. If you pay interest or a fee, log it as a work expense.</p>';
    return h;
  }
};

/* ============================================================ ASSETS */
PAGES.assets = {
  title: 'Assets', render() {
    const list = db().assets.slice().sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
    let h = '<div class="stats"><div class="stat"><div class="sk">Value owned</div><div class="sv">' + money(list.reduce((s, a) => s + num(a.value), 0)) + '</div></div><div class="stat"><div class="sk">Items</div><div class="sv">' + list.length + '</div></div></div>';
    h += '<div class="card" style="margin-top:12px">' + (list.length ? list.map(a => flowRow({ kind: 'asset', date: a.date || '', amount: num(a.value), asset: a })).join('') : emptyBox('building-factory-2', 'No assets yet.')) + '</div>';
    h += '<button class="btn" data-act="editAsset">' + icon('plus') + 'Add an asset</button>';
    h += '<p class="note">A machine, car or tools the business owns. Buying one takes from cash in hand but not from profit, because you still own its value.</p>';
    return h;
  }
};
