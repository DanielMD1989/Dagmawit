/* ============================================================
   forms.ts — every sheet: viewing an order or loan, and every form
   that changes data. Forms validate inline (no pop-ups), deletes
   offer Undo, and saved customer records are never overwritten.
   ============================================================ */
import type { Expense, Freq, Id, Order, Scope } from './types';
import { ACT, type SheetFn, type SheetView } from './registry';
import { icon } from './icons';
import { client, db, loadBackups, makeBackup, restoreBackup } from './sync';
import { esc, fmtNum, lower, niceDate, num, sameId, today, uid } from './util';
import {
  CUR, FCUR, UI, closeSheets, closeSide, commit, emptyBox, finishForm, money, openSheet, removeWithUndo, toast
} from './ui';
import {
  CATEGORIES, ensureCustomer, findCustomerByName, isForeign, loanLeft, loanRepaid, orderLeft, orderPaid,
  ordersForCustomer, owedByCustomer, quickPicks, scopeOf, scopeWord, suggestCategory, suggestScope
} from './model';
import { orderRow } from './screens';

/* ---------- small, typed form helpers ---------- */
function el<T extends HTMLElement = HTMLInputElement>(root: HTMLElement, id: string): T {
  const x = root.querySelector('#' + id);
  if (!x) throw new Error('Missing #' + id);
  return x as T;
}
const opt = <T extends HTMLElement = HTMLElement>(root: HTMLElement, id: string): T | null => root.querySelector('#' + id) as T | null;
const fval = (root: HTMLElement, id: string): string => (opt<HTMLInputElement>(root, id)?.value || '').trim();
/** Show (or clear) an inline error under a field. Returns true when there is no error. */
function setErr(root: HTMLElement, id: string, msg: string): boolean {
  const box = opt(root, id + '_err'); if (box) box.textContent = msg;
  if (msg) opt(root, id)?.focus();
  return !msg;
}
function fld(label: string, inner: string, id?: string | null, hint?: string): string {
  return '<div class="field">' + (label ? '<label' + (id ? ' for="' + id + '"' : '') + '>' + label + '</label>' : '') + inner + (hint ? '<div class="hint">' + hint + '</div>' : '') + (id ? '<div class="err" id="' + id + '_err"></div>' : '') + '</div>';
}
const amountInput = (id: string, value: unknown, big = false): string => '<input class="input' + (big ? ' big' : '') + '" id="' + id + '" type="number" inputmode="decimal" min="0" step="any" placeholder="0" value="' + (value ? esc(value) : '') + '">';
const textInput = (id: string, value: unknown, ph: string): string => '<input class="input" id="' + id + '" value="' + esc(value || '') + '" placeholder="' + esc(ph) + '">';
const dateInput = (id: string, value: unknown): string => '<input class="input" id="' + id + '" type="date" value="' + esc(value || today()) + '">';
const seg = (id: string, options: [string, string][], current: string | null): string => '<div class="seg" id="' + id + '">' + options.map(o => '<button type="button" data-v="' + o[0] + '" class="' + (o[0] === current ? 'on' : '') + '">' + o[1] + '</button>').join('') + '</div>';
function wireSeg(root: HTMLElement, id: string, onPick: (v: string) => void): void {
  const box = el<HTMLElement>(root, id);
  box.querySelectorAll<HTMLButtonElement>('button').forEach(b => b.onclick = () => { box.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); onPick(b.dataset.v || ''); });
}
function paintSeg(root: HTMLElement, id: string, v: string): void { el<HTMLElement>(root, id).querySelectorAll<HTMLElement>('button').forEach(x => x.classList.toggle('on', x.dataset.v === v)); }
const findOrder = (id: Id | undefined): Order | undefined => db().orders.find(o => sameId(o.id, id));
const findLoan = (id: Id | undefined) => db().loans.find(l => sameId(l.id, id));
const findExpense = (id: Id | undefined): Expense | undefined => db().expenses.find(x => sameId(x.id, id));
const viewSheet = (fn: SheetFn): void => openSheet(fn, { kind: 'page' });
const formSheet = (fn: SheetFn): void => openSheet(fn, { form: true });
type View = SheetView;

/* ============================================================ ADD MENU */
ACT.openAdd = () => openSheet((): View => ({
  title: 'Add', html: '<div class="quick" style="grid-template-columns:repeat(2,1fr);margin-top:0">'
    + '<button data-act="gotPaid">' + icon('cash') + 'Got paid</button>'
    + '<button data-act="spent">' + icon('receipt-2') + 'Spent</button>'
    + '<button data-act="newOrder">' + icon('plus') + 'New order</button>'
    + '<button data-act="bazar">' + icon('building-store') + 'Bazar sale</button>'
    + '<button data-act="newLoan">' + icon('building-bank') + 'Loan received</button>'
    + '<button data-act="editAsset">' + icon('building-factory-2') + 'Asset bought</button></div>'
    + '<p class="note">Got paid: money from a customer for an order. Spent: any work or home cost.</p>'
}));

/* ============================================================ GOT PAID — pick the order */
ACT.gotPaid = () => openSheet((): View => {
  const open = db().orders.filter(o => orderLeft(o) > 0)
    .sort((a, b) => String(a.customer || '').localeCompare(String(b.customer || '')) || String(a.created || '').localeCompare(String(b.created || '')));
  return {
    title: 'Who paid?',
    html: '<div class="search">' + icon('search') + '<input id="gpQ" placeholder="Search name or item" autocomplete="off"></div>'
      + '<div class="card" id="gpList">' + (open.length ? open.map(o => '<button class="row" data-act="recordPayment" data-id="' + esc(o.id) + '" data-s="' + esc(lower([o.customer, o.clothType, o.phone].join(' '))) + '"><div class="body"><div class="t1">' + esc(o.customer || 'Customer') + '</div><div class="t2">' + esc([o.clothType, 'ordered ' + niceDate(o.created)].filter(Boolean).join(' · ')) + '</div></div><div class="end"><div class="amt out">' + money(orderLeft(o), isForeign(o) ? FCUR() : CUR()) + '</div><div class="sub">left</div></div></button>').join('') : emptyBox('check', 'No order is waiting for payment.')) + '</div>'
      + '<button class="btn line" data-act="newOrder">' + icon('plus') + 'New order, paid now</button>'
      + '<button class="btn line" data-act="bazar">' + icon('building-store') + 'Bazar sale</button>',
    after(root) {
      // filter rows in place (re-rendering would close the keyboard)
      el(root, 'gpQ').oninput = e => {
        const s = lower((e.target as HTMLInputElement).value);
        root.querySelectorAll<HTMLElement>('#gpList .row').forEach(r => { r.style.display = !s || (r.dataset.s || '').includes(s) ? '' : 'none'; });
      };
    }
  };
});

/* ============================================================ ORDER PAGE */
function orderSheet(id: Id): SheetFn {
  return () => {
    const o = findOrder(id); if (!o) return null;
    const fx = isForeign(o), cur = fx ? FCUR() : CUR(), paid = orderPaid(o), left = orderLeft(o), pct = o.total > 0 ? Math.min(100, Math.round(paid / o.total * 100)) : 0;
    const pays = (o.payments || []).slice().sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));
    let h = '<div class="card pad"><div style="font-size:20px;font-weight:700">' + esc(o.customer || 'Customer') + '</div>'
      + '<div class="t2" style="color:var(--muted);font-size:14px">' + esc([o.clothType, 'ordered ' + niceDate(o.created)].filter(Boolean).join(' · ')) + '</div>'
      + (o.orderType === 'bazar' ? '<span class="tag">Bazar sale</span> ' : '') + (fx ? '<span class="tag warn">Website · ' + esc(FCUR()) + '</span>' : '')
      + '<div class="bar" style="height:8px;margin-top:14px"><i style="width:' + pct + '%"></i></div>'
      + '<div style="display:flex;justify-content:space-between;margin-top:8px;font-size:14.5px"><span>Paid <b>' + money(paid, cur) + '</b> of ' + money(o.total, cur) + '</span>' + (left > 0 ? '<b style="color:var(--out)">' + money(left, cur) + ' left</b>' : '<b style="color:var(--in)">Paid in full</b>') + '</div></div>';
    if (o.phone) h += '<div class="card" style="margin-top:12px"><a class="kv" href="tel:' + esc(o.phone) + '" style="color:inherit;text-decoration:none"><span>Phone</span><b style="color:var(--main)">' + esc(o.phone) + '</b></a></div>';
    h += '<div class="sec"><h2>Payments</h2></div><div class="card">' + (pays.length ? pays.map(p => '<button class="row" data-act="editPayment" data-order="' + esc(o.id) + '" data-id="' + esc(p.id) + '"><div class="av in">' + icon('cash') + '</div><div class="body"><div class="t1">' + niceDate(p.date) + '</div><div class="t2">' + esc(p.note || 'Payment') + '</div></div><div class="end"><div class="amt in">' + money(p.amount, cur) + '</div></div></button>').join('') : emptyBox('cash', 'No payments yet.'))
      + (left > 0 && pays.length ? '<div class="kv"><span>Still to pay</span><b style="color:var(--out)">' + money(left, cur) + '</b></div>' : '') + '</div>';
    if (left > 0) h += '<button class="btn" data-act="recordPayment" data-id="' + esc(o.id) + '">' + icon('cash') + 'Record payment</button>';
    h += '<div class="btnrow">' + (o.phone && left > 0 ? '<button class="btn line" data-act="remind" data-id="' + esc(o.id) + '">' + icon('message-2') + 'Remind</button>' : '') + '<button class="btn line" data-act="editOrder" data-id="' + esc(o.id) + '">' + icon('edit') + 'Edit order</button></div>';
    return { title: 'Order', html: h };
  };
}
ACT.openOrder = e => viewSheet(orderSheet(e.dataset.id || ''));
ACT.recordPayment = e => formSheet(paymentForm(e.dataset.id || '', null));
ACT.editPayment = e => formSheet(paymentForm(e.dataset.order || '', e.dataset.id || null));
ACT.editOrder = e => formSheet(orderForm(e.dataset.id || null));
ACT.newOrder = () => formSheet(orderForm(null));

function smsLink(phone: string, name: string, amount: number, item?: string): string {
  const msg = 'Hello ' + name + ', this is a friendly reminder from DAGMAWIT about your balance of ' + CUR() + ' ' + fmtNum(amount) + (item ? ' for the ' + item : '') + '. Thank you!';
  return 'sms:' + phone + '?&body=' + encodeURIComponent(msg);
}
ACT.remind = e => { const o = findOrder(e.dataset.id); if (o && o.phone) window.location.href = smsLink(o.phone, o.customer || '', orderLeft(o), o.clothType); };

/* ============================================================ PAYMENT FORM */
function paymentForm(orderId: Id, payId: Id | null): SheetFn {
  return () => {
    const o = findOrder(orderId); if (!o) return null;
    const p = payId != null ? o.payments.find(x => sameId(x.id, payId)) : undefined;
    if (payId != null && !p) return null;
    const cur = isForeign(o) ? FCUR() : CUR(), max = orderLeft(o) + (p ? num(p.amount) : 0);
    const html = '<p class="note" style="margin:0 4px 4px">' + esc(o.customer || 'Customer') + (o.clothType ? ' · ' + esc(o.clothType) : '') + ' · ' + money(max, cur) + ' ' + (p ? 'can be on this payment' : 'left to pay') + '</p>'
      + fld('Amount received (' + esc(cur) + ')', amountInput('pa_amt', p ? p.amount : max, true), 'pa_amt')
      + '<div class="chips" style="margin-top:8px"><button class="chip" data-fill="' + max + '">All ' + fmtNum(max) + '</button>' + (max >= 2 ? '<button class="chip" data-fill="' + Math.round(max / 2) + '">Half ' + fmtNum(Math.round(max / 2)) + '</button>' : '') + '</div>'
      + fld('Date received', dateInput('pa_date', p ? p.date : today()), 'pa_date')
      + fld('How (optional)', textInput('pa_note', p ? p.note : '', 'Cash, Telebirr, bank transfer…'))
      + '<button class="btn" id="pa_save">' + (p ? 'Save payment' : 'Record payment') + '</button>'
      + (p ? '<button class="btn danger" id="pa_del">Delete this payment</button>' : '');
    return {
      title: p ? 'Edit payment' : 'Record payment', html, after(root) {
        root.querySelectorAll<HTMLElement>('[data-fill]').forEach(b => b.onclick = () => { el(root, 'pa_amt').value = b.dataset.fill || ''; });
        el(root, 'pa_save').onclick = () => {
          const amt = num(fval(root, 'pa_amt')), date = fval(root, 'pa_date');
          if (!setErr(root, 'pa_amt', amt > 0 ? '' : 'Enter the amount received')) return;
          if (!setErr(root, 'pa_amt', amt <= max + 0.001 ? '' : 'That is more than the ' + fmtNum(max) + ' left. Change the order price first if it went up.')) return;
          if (!setErr(root, 'pa_date', date ? '' : 'Pick the date')) return;
          const ord = findOrder(orderId); if (!ord) { closeSheets(); return; }
          const data = { amount: amt, date, note: fval(root, 'pa_note') };
          const existing = p ? ord.payments.find(x => sameId(x.id, payId)) : undefined;
          if (existing) Object.assign(existing, data); else ord.payments.push({ id: uid(), ...data });
          ord.paid = orderPaid(ord);
          commit(); finishForm();
          toast(orderLeft(ord) <= 0 ? 'Paid in full' : 'Payment saved · ' + money(orderLeft(ord), cur) + ' left');
        };
        if (p) el(root, 'pa_del').onclick = () => {
          const undo = removeWithUndo(() => findOrder(orderId)?.payments, x => sameId(x.id, payId));
          const fix = (): void => { const x = findOrder(orderId); if (x) x.paid = orderPaid(x); };
          fix(); commit(); finishForm();
          toast('Payment deleted', () => { undo(); fix(); });
        };
      }
    };
  };
}

/* ============================================================ ORDER FORM */
function orderForm(id: Id | null): SheetFn {
  return () => {
    const d = db(), o = id != null ? findOrder(id) : undefined;
    if (id != null && !o) return null;
    let foreign = o ? isForeign(o) : false;
    const curOf = (): string => foreign ? FCUR() : CUR();
    const html = fld('Customer name', '<input class="input" id="of_cust" list="of_custlist" autocomplete="off" value="' + esc(o ? o.customer : '') + '" placeholder="Type or pick a saved name"><datalist id="of_custlist">' + d.customers.map(c => '<option value="' + esc(c.name) + '">').join('') + '</datalist>', 'of_cust')
      + fld('Phone', '<input class="input" id="of_phone" type="tel" value="' + esc(o ? o.phone : '') + '" placeholder="09…">', null, '<span id="of_hint"></span>')
      + fld('What is it', textInput('of_item', o ? o.clothType : '', 'Wedding dress, women suit…'))
      + '<div class="field"><button type="button" class="switch' + (foreign ? ' on' : '') + '" id="of_fx">Website order, paid in ' + esc(FCUR()) + '<i></i></button></div>'
      + fld('Price (<span id="of_cur1">' + esc(curOf()) + '</span>)', amountInput('of_total', o ? o.total : '', true), 'of_total')
      + fld('Order date', dateInput('of_date', o ? o.created : today()), 'of_date')
      + (o ? '<p class="note">Payments are on the order page: open the order and tap Record payment.</p>'
        : fld('Paid now (<span id="of_cur2">' + esc(curOf()) + '</span>)', amountInput('of_paid', ''), 'of_paid', 'Leave empty if nothing was paid yet.') + '<div class="chips" style="margin-top:8px"><button class="chip" id="of_full">Paid in full</button></div>')
      + '<button class="btn" id="of_save">' + (o ? 'Save changes' : 'Save order') + '</button>'
      + (o ? '<button class="btn danger" id="of_del">Delete order</button>' : '');
    return {
      title: o ? 'Edit order' : 'New order', html, after(root) {
        el<HTMLButtonElement>(root, 'of_fx').onclick = () => {
          foreign = !foreign;
          el<HTMLElement>(root, 'of_fx').classList.toggle('on', foreign);
          el<HTMLElement>(root, 'of_cur1').textContent = curOf();
          const c2 = opt(root, 'of_cur2'); if (c2) c2.textContent = curOf();
        };
        el(root, 'of_cust').onchange = () => {
          const c = findCustomerByName(db(), fval(root, 'of_cust'));
          if (c && c.phone && !fval(root, 'of_phone')) { el(root, 'of_phone').value = c.phone; el<HTMLElement>(root, 'of_hint').textContent = 'Filled in from the saved customer.'; }
        };
        if (!o) el<HTMLButtonElement>(root, 'of_full').onclick = () => { el(root, 'of_paid').value = fval(root, 'of_total'); };
        el<HTMLButtonElement>(root, 'of_save').onclick = () => {
          const name = fval(root, 'of_cust'), phone = fval(root, 'of_phone'), total = num(fval(root, 'of_total')), date = fval(root, 'of_date');
          if (!setErr(root, 'of_cust', name ? '' : 'Enter the customer name')) return;
          if (!setErr(root, 'of_total', total > 0 ? '' : 'Enter the price')) return;
          if (!setErr(root, 'of_date', date ? '' : 'Pick the order date')) return;
          const D = db(), fields = { customer: name, customerId: ensureCustomer(D, name, phone), phone, clothType: fval(root, 'of_item'), total, created: date, currency: foreign ? 'foreign' : 'local' };
          if (o) {
            const ord = findOrder(id ?? undefined); if (!ord) { closeSheets(); return; }
            if (!setErr(root, 'of_total', total + 0.001 >= orderPaid(ord) ? '' : 'Price cannot be less than what was already paid (' + fmtNum(orderPaid(ord)) + '). Delete a payment first.')) return;
            Object.assign(ord, fields);
            commit(); finishForm(); toast('Order saved');
          } else {
            const paid = num(fval(root, 'of_paid'));
            if (!setErr(root, 'of_paid', paid <= total + 0.001 ? '' : 'Paid now cannot be more than the price')) return;
            const ord: Order = { id: uid(), ...fields, orderType: 'custom', channel: 'In person',
              payType: paid >= total ? 'Full upfront' : paid > 0 ? 'Advance' : 'On delivery',
              payments: paid > 0 ? [{ id: uid(), amount: paid, date, note: 'Paid when ordering' }] : [] };
            ord.paid = orderPaid(ord);
            D.orders.push(ord);
            commit(); closeSheets(); viewSheet(orderSheet(ord.id)); toast('Order saved');
          }
        };
        if (o) el<HTMLButtonElement>(root, 'of_del').onclick = () => {
          const undo = removeWithUndo(() => db().orders, x => sameId(x.id, id));
          commit(); closeSheets(); toast('Order deleted', undo);
        };
      }
    };
  };
}

/* ============================================================ BAZAR SALE */
ACT.bazar = () => formSheet((): View => ({
  title: 'Bazar sale',
  html: fld('What was sold', textInput('bz_item', '', 'Scarf, dress…'))
    + fld('Price (' + esc(CUR()) + ')', amountInput('bz_total', '', true), 'bz_total')
    + '<div class="field"><button type="button" class="switch on" id="bz_full">Paid in full now<i></i></button></div>'
    + '<div id="bz_partwrap" style="display:none">' + fld('Paid now (' + esc(CUR()) + ')', amountInput('bz_paid', ''), 'bz_paid', 'The rest shows under Owed to you.') + '</div>'
    + fld('Customer name (optional)', textInput('bz_cust', '', 'Walk-in customer'))
    + fld('Phone (optional)', '<input class="input" id="bz_phone" type="tel" placeholder="09…">')
    + '<button class="btn" id="bz_save">Save sale</button>',
  after(root) {
    let full = true;
    el<HTMLButtonElement>(root, 'bz_full').onclick = () => { full = !full; el<HTMLElement>(root, 'bz_full').classList.toggle('on', full); el<HTMLElement>(root, 'bz_partwrap').style.display = full ? 'none' : ''; };
    el<HTMLButtonElement>(root, 'bz_save').onclick = () => {
      const total = num(fval(root, 'bz_total'));
      if (!setErr(root, 'bz_total', total > 0 ? '' : 'Enter the price')) return;
      const paid = full ? total : num(fval(root, 'bz_paid'));
      if (!full && !setErr(root, 'bz_paid', paid <= total ? '' : 'Cannot be more than the price')) return;
      const t = today();
      const o: Order = { id: uid(), created: t, customer: fval(root, 'bz_cust') || 'Bazar customer', phone: fval(root, 'bz_phone'), clothType: fval(root, 'bz_item'), total, currency: 'local', orderType: 'bazar', channel: 'In person',
        payType: paid >= total ? 'Full upfront' : paid > 0 ? 'Advance' : 'On delivery', payments: paid > 0 ? [{ id: uid(), amount: paid, date: t, note: 'Bazar' }] : [] };
      o.paid = orderPaid(o);
      db().orders.push(o); commit(); closeSheets(); toast('Sale saved');
    };
  }
}));

/* ============================================================ WHO OWES */
const groupByKey = (key: string | undefined) => owedByCustomer(db()).find(g => g.key === key);
ACT.whoOwes = () => openSheet((): View => {
  const g = owedByCustomer(db());
  return {
    title: 'Owed to you', html: '<div class="stats"><div class="stat"><div class="sk">Total</div><div class="sv" style="color:var(--out)">' + money(g.reduce((s, x) => s + x.left, 0)) + '</div></div><div class="stat"><div class="sk">Customers</div><div class="sv">' + g.length + '</div></div></div>'
      + '<div class="card" style="margin-top:12px">' + (g.length ? g.map(x => '<div class="row"><button class="body" style="text-align:left" data-act="payCustomer" data-key="' + esc(x.key) + '"><div class="t1">' + esc(x.name) + '</div><div class="t2">' + x.orders.length + ' order' + (x.orders.length > 1 ? 's' : '') + ' · since ' + niceDate(x.oldest) + '</div></button><div class="end"><div class="amt out">' + money(x.left) + '</div></div>'
        + (x.phone ? '<button class="iconbtn" data-act="remindCustomer" data-key="' + esc(x.key) + '" aria-label="Send reminder">' + icon('message-2') + '</button>' : '') + '</div>').join('') : emptyBox('check', 'Nobody owes you right now.')) + '</div>'
      + '<p class="note">Biggest first. Tap a name to record a payment; the message button opens a friendly SMS reminder.</p>'
  };
});
ACT.payCustomer = e => {
  const key = e.dataset.key, g = groupByKey(key); if (!g) return;
  const only = g.orders.length === 1 ? g.orders[0] : undefined;
  if (only) { formSheet(paymentForm(only.id, null)); return; }
  openSheet((): View | null => {
    const x = groupByKey(key); if (!x) return null;
    return { title: x.name, html: '<p class="note" style="margin:0 4px 8px">Which order was paid?</p><div class="card">' + x.orders.map(o => '<button class="row" data-act="recordPayment" data-id="' + esc(o.id) + '"><div class="body"><div class="t1">' + esc(o.clothType || 'Order') + '</div><div class="t2">ordered ' + niceDate(o.created) + ' · paid ' + money(orderPaid(o)) + ' of ' + money(o.total) + '</div></div><div class="end"><div class="amt out">' + money(orderLeft(o)) + '</div><div class="sub">left</div></div></button>').join('') + '</div>' };
  });
};
ACT.remindCustomer = e => { const g = groupByKey(e.dataset.key); if (g && g.phone) window.location.href = smsLink(g.phone, g.name, g.left, g.orders.length === 1 ? g.orders[0]?.clothType : ''); };

/* ============================================================ SPENT (expense) FORM
   One form for every cost. The app suggests work or home, and the
   category, from her own past entries; she can always change it. */
interface ExpensePreset { cat?: string; scope?: Scope; amount?: number; note?: string; employee?: string; freq?: string; }
function expenseForm(id: Id | null, preset: ExpensePreset | null): SheetFn {
  return () => {
    const d = db(), e = id != null ? findExpense(id) : undefined;
    if (id != null && !e) return null;
    if (e && e.loanId != null) return repayForm(e.loanId, e.id)();
    const src: ExpensePreset = e ? { cat: e.cat, scope: scopeOf(e), amount: e.amount, note: e.note, employee: e.employee, freq: String(e.freq || 'once') } : (preset || {});
    const st = { cat: src.cat || null as string | null, scope: src.scope || null as Scope | null, manualScope: !!src.scope, manualCat: !!src.cat, freq: (src.freq || 'once') as Freq };
    const picks = e ? [] : quickPicks(d, 4);
    const html = (picks.length ? '<div class="flabel" style="margin-top:2px">Again?</div><div class="picks">' + picks.map((p, i) => '<button type="button" data-pick="' + i + '"><b>' + esc(p.employee || p.note || p.cat) + '</b><span>' + esc(p.cat) + ' · ' + money(p.amount) + ' · ' + scopeWord(p.scope) + '</span></button>').join('') + '</div>' : '')
      + fld('Amount (' + esc(CUR()) + ')', amountInput('ex_amt', src.amount, true), 'ex_amt')
      + '<div class="field"><div class="flabel">For</div><div class="catgrid" id="ex_cats">' + CATEGORIES.map(c => '<button type="button" data-cat="' + esc(c.k) + '" class="' + (st.cat === c.k ? 'on' : '') + '">' + icon(c.ic) + esc(c.k) + '</button>').join('') + '</div><div class="err" id="ex_cats_err"></div></div>'
      + '<div id="ex_empwrap" style="display:' + (st.cat === 'Salaries' ? '' : 'none') + '">' + fld('Paid to', textInput('ex_emp', src.employee, 'Name')) + '</div>'
      + fld('Note (optional)', textInput('ex_note', src.note, 'Cotton from Merkato, shop rent…'))
      + '<div class="field"><div class="flabel">Work or home</div>' + seg('ex_scope', [['biz', 'Work'], ['home', 'Home']], st.scope) + '<div class="hint" id="ex_sugg"></div><div class="err" id="ex_scope_err"></div></div>'
      + fld('Date', dateInput('ex_date', e ? e.date : today()), 'ex_date')
      + '<div class="field"><div class="flabel">Repeats</div>' + seg('ex_freq', [['once', 'No'], ['week', 'Weekly'], ['month', 'Monthly'], ['quarter', '3 months']], st.freq) + '<div class="hint">Repeating costs show under Coming up two weeks before they are due.</div></div>'
      + '<button class="btn" id="ex_save">' + (e ? 'Save changes' : 'Save') + '</button>'
      + (e ? '<button class="btn danger" id="ex_del">Delete</button>' : '');
    return {
      title: e ? 'Edit expense' : 'Spent', html, after(root) {
        const showEmp = (): void => { el<HTMLElement>(root, 'ex_empwrap').style.display = st.cat === 'Salaries' ? '' : 'none'; };
        const paintCats = (): void => el<HTMLElement>(root, 'ex_cats').querySelectorAll<HTMLElement>('button').forEach(b => b.classList.toggle('on', b.dataset.cat === st.cat));
        const suggest = (): void => {
          const hint = el<HTMLElement>(root, 'ex_sugg');
          if (!st.cat) { hint.textContent = 'Pick what it was for and the app suggests work or home.'; hint.className = 'hint'; return; }
          const s = suggestScope(db(), st.cat, fval(root, 'ex_note'), fval(root, 'ex_emp'));
          if (!st.manualScope) { st.scope = s.scope; paintSeg(root, 'ex_scope', s.scope); hint.textContent = 'Suggested: ' + scopeWord(s.scope) + ' · ' + s.text + '.'; hint.className = 'hint ok'; }
          else if (s.learned && s.scope !== st.scope) { hint.textContent = 'Usually ' + scopeWord(s.scope) + ' (' + s.text + ').'; hint.className = 'hint'; }
          else hint.textContent = '';
        };
        el<HTMLElement>(root, 'ex_cats').querySelectorAll<HTMLButtonElement>('button').forEach(b => b.onclick = () => {
          st.cat = b.dataset.cat || null; st.manualCat = true; paintCats(); setErr(root, 'ex_cats', ''); showEmp(); suggest();
        });
        wireSeg(root, 'ex_scope', v => { st.scope = v === 'home' ? 'home' : 'biz'; st.manualScope = true; setErr(root, 'ex_scope', ''); suggest(); });
        wireSeg(root, 'ex_freq', v => { st.freq = v as Freq; });
        el(root, 'ex_note').oninput = () => {
          if (!st.manualCat) { const c = suggestCategory(db(), fval(root, 'ex_note')); if (c) { st.cat = c; paintCats(); showEmp(); } }
          suggest();
        };
        el(root, 'ex_emp').oninput = suggest;
        root.querySelectorAll<HTMLElement>('[data-pick]').forEach(b => b.onclick = () => {
          const p = picks[Number(b.dataset.pick)]; if (!p) return;
          el(root, 'ex_amt').value = String(p.amount); el(root, 'ex_note').value = p.note; el(root, 'ex_emp').value = p.employee;
          Object.assign(st, { cat: p.cat, scope: p.scope, manualCat: true, manualScope: true, freq: (p.recurring ? p.freq : 'once') as Freq });
          paintCats(); paintSeg(root, 'ex_scope', p.scope); paintSeg(root, 'ex_freq', st.freq); showEmp(); suggest();
        });
        suggest();
        el<HTMLButtonElement>(root, 'ex_save').onclick = () => {
          const amount = num(fval(root, 'ex_amt')), date = fval(root, 'ex_date');
          if (!setErr(root, 'ex_amt', amount > 0 ? '' : 'Enter the amount')) return;
          if (!st.cat) { setErr(root, 'ex_cats', 'Pick what it was for'); return; }
          if (!st.scope) { setErr(root, 'ex_scope', 'Pick work or home'); return; }
          if (!setErr(root, 'ex_date', date ? '' : 'Pick the date')) return;
          const data = { cat: st.cat, amount, date, note: fval(root, 'ex_note'), employee: st.cat === 'Salaries' ? fval(root, 'ex_emp') : '', scope: st.scope, recurring: st.freq !== 'once', freq: st.freq };
          const cur = e ? findExpense(id ?? undefined) : undefined;
          if (cur) Object.assign(cur, data); else db().expenses.push({ id: uid(), ...data });
          commit(); finishForm(); toast('Saved as ' + scopeWord(st.scope) + ' · ' + st.cat);
        };
        if (e) el<HTMLButtonElement>(root, 'ex_del').onclick = () => {
          const undo = removeWithUndo(() => db().expenses, x => sameId(x.id, id));
          commit(); finishForm(); toast('Expense deleted', undo);
        };
      }
    };
  };
}
ACT.spent = () => formSheet(expenseForm(null, null));
ACT.editExpense = e => formSheet(expenseForm(e.dataset.id || '', null));
ACT.repeatExpense = e => {
  const x = findExpense(e.dataset.id); if (!x) return;
  formSheet(expenseForm(null, { cat: x.cat, scope: scopeOf(x), amount: x.amount, note: x.note, employee: x.employee, freq: String(x.freq || 'once') }));
};

/* ============================================================ LOANS */
function loanSheet(id: Id): SheetFn {
  return () => {
    const d = db(), l = findLoan(id); if (!l) return null;
    const reps = d.expenses.filter(e => sameId(e.loanId, l.id)).sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));
    const left = loanLeft(d, l);
    const h = '<div class="card"><div class="kv"><span>Borrowed from</span><b>' + esc(l.lender || '—') + '</b></div><div class="kv"><span>Amount</span><b>' + money(l.total) + '</b></div><div class="kv"><span>Received</span><b>' + niceDate(l.received) + '</b></div><div class="kv"><span>Repaid</span><b>' + money(num(l.total) - left) + '</b></div><div class="kv"><span>Left to repay</span><b style="color:var(--loan)">' + money(left) + '</b></div>' + (l.note ? '<div class="kv"><span>Note</span><b>' + esc(l.note) + '</b></div>' : '') + '</div>'
      + '<div class="sec"><h2>Repayments</h2></div><div class="card">' + (reps.length ? reps.map(e => '<button class="row" data-act="editRepay" data-loan="' + esc(l.id) + '" data-id="' + esc(e.id) + '"><div class="av loan">' + icon('building-bank') + '</div><div class="body"><div class="t1">' + niceDate(e.date) + '</div><div class="t2">' + esc(e.note || 'Repayment') + '</div></div><div class="end"><div class="amt loan">' + money(e.amount) + '</div></div></button>').join('') : emptyBox('building-bank', 'No repayments yet.')) + '</div>'
      + (left > 0 ? '<button class="btn" data-act="repay" data-id="' + esc(l.id) + '">' + icon('cash') + 'Log a repayment</button>' : '')
      + '<button class="btn line" data-act="editLoan" data-id="' + esc(l.id) + '">' + icon('edit') + 'Edit loan</button>';
    return { title: l.lender || 'Loan', html: h };
  };
}
ACT.openLoan = e => viewSheet(loanSheet(e.dataset.id || ''));
ACT.newLoan = () => formSheet(loanForm(null));
ACT.editLoan = e => formSheet(loanForm(e.dataset.id || null));
ACT.repay = e => formSheet(repayForm(e.dataset.id || '', null));
ACT.editRepay = e => formSheet(repayForm(e.dataset.loan || '', e.dataset.id || null));

function loanForm(id: Id | null): SheetFn {
  return () => {
    const l = id != null ? findLoan(id) : undefined;
    if (id != null && !l) return null;
    const html = fld('Borrowed from', textInput('lf_lender', l ? l.lender : '', 'Bank, family member…'), 'lf_lender')
      + fld('Amount (' + esc(CUR()) + ')', amountInput('lf_total', l ? l.total : '', true), 'lf_total')
      + fld('Date received', dateInput('lf_date', l ? l.received : today()), 'lf_date')
      + fld('Note (optional)', textInput('lf_note', l ? l.note : '', 'Monthly payment on the 5th…'))
      + '<p class="note">The money adds to cash in hand on this date. It is not income, so it does not change profit.</p>'
      + '<button class="btn" id="lf_save">' + (l ? 'Save loan' : 'Add loan') + '</button>'
      + (l ? '<button class="btn danger" id="lf_del">Delete loan and its repayments</button>' : '');
    return {
      title: l ? 'Edit loan' : 'Loan received', html, after(root) {
        el<HTMLButtonElement>(root, 'lf_save').onclick = () => {
          const lender = fval(root, 'lf_lender'), total = num(fval(root, 'lf_total')), date = fval(root, 'lf_date');
          if (!setErr(root, 'lf_lender', lender ? '' : 'Who lent the money?')) return;
          if (!setErr(root, 'lf_total', total > 0 ? '' : 'Enter the amount')) return;
          if (l && !setErr(root, 'lf_total', total + 0.001 >= loanRepaid(db(), l) ? '' : 'Cannot be less than what was already repaid (' + fmtNum(loanRepaid(db(), l)) + ')')) return;
          if (!setErr(root, 'lf_date', date ? '' : 'Pick the date')) return;
          const data = { lender, total, received: date, note: fval(root, 'lf_note') };
          const cur = l ? findLoan(id ?? undefined) : undefined;
          if (cur) Object.assign(cur, data); else db().loans.push({ id: uid(), created: date, purpose: 'business', ...data });
          commit(); finishForm(); toast(l ? 'Loan saved' : 'Loan added · cash in hand updated');
        };
        if (l) el<HTMLButtonElement>(root, 'lf_del').onclick = () => {
          const u1 = removeWithUndo(() => db().loans, x => sameId(x.id, id));
          const u2 = removeWithUndo(() => db().expenses, x => sameId(x.loanId, id));
          commit(); closeSheets(); toast('Loan deleted', () => { u1(); u2(); });
        };
      }
    };
  };
}

function repayForm(loanId: Id, expId: Id | null): SheetFn {
  return () => {
    const d = db(), l = findLoan(loanId); if (!l) return null;
    const e = expId != null ? findExpense(expId) : undefined;
    if (expId != null && !e) return null;
    const max = loanLeft(d, l) + (e ? num(e.amount) : 0);
    const html = '<p class="note" style="margin:0 4px 4px">' + esc(l.lender || 'Loan') + ' · ' + money(max) + ' left to repay</p>'
      + fld('Amount repaid (' + esc(CUR()) + ')', amountInput('rp_amt', e ? e.amount : '', true), 'rp_amt')
      + '<div class="chips" style="margin-top:8px"><button class="chip" data-fill="' + max + '">All ' + fmtNum(max) + '</button></div>'
      + fld('Date', dateInput('rp_date', e ? e.date : today()), 'rp_date')
      + fld('Note (optional)', textInput('rp_note', e ? e.note : '', ''))
      + '<p class="note">This takes from cash in hand but is not an expense. If the lender charged interest or a fee, log that part with Spent as a work expense.</p>'
      + '<button class="btn" id="rp_save">' + (e ? 'Save' : 'Log repayment') + '</button>'
      + (e ? '<button class="btn danger" id="rp_del">Delete this repayment</button>' : '');
    return {
      title: e ? 'Edit repayment' : 'Repayment', html, after(root) {
        root.querySelectorAll<HTMLElement>('[data-fill]').forEach(b => b.onclick = () => { el(root, 'rp_amt').value = b.dataset.fill || ''; });
        el<HTMLButtonElement>(root, 'rp_save').onclick = () => {
          const amount = num(fval(root, 'rp_amt')), date = fval(root, 'rp_date');
          if (!setErr(root, 'rp_amt', amount > 0 ? '' : 'Enter the amount')) return;
          if (!setErr(root, 'rp_amt', amount <= max + 0.001 ? '' : 'More than the ' + fmtNum(max) + ' left. If part of it is interest, log that part with Spent.')) return;
          if (!setErr(root, 'rp_date', date ? '' : 'Pick the date')) return;
          const data = { amount, date, note: fval(root, 'rp_note') };
          const cur = e ? findExpense(expId ?? undefined) : undefined;
          if (cur) Object.assign(cur, data);
          else db().expenses.push({ id: uid(), cat: 'Loan repayment', scope: l.purpose === 'household' ? 'home' : 'biz', loanId: l.id, recurring: false, freq: 'once', ...data });
          commit(); finishForm();
          const now = findLoan(loanId);
          toast(now && loanLeft(db(), now) <= 0 ? 'Loan cleared' : 'Repayment logged');
        };
        if (e) el<HTMLButtonElement>(root, 'rp_del').onclick = () => {
          const undo = removeWithUndo(() => db().expenses, x => sameId(x.id, expId));
          commit(); finishForm(); toast('Repayment deleted', undo);
        };
      }
    };
  };
}

/* ============================================================ ASSETS */
function assetForm(id: Id | null): SheetFn {
  return () => {
    const a = id != null ? db().assets.find(x => sameId(x.id, id)) : undefined;
    if (id != null && !a) return null;
    const html = fld('What is it', textInput('as_name', a ? a.name : '', 'Sewing machine, car…'), 'as_name')
      + fld('Cost (' + esc(CUR()) + ')', amountInput('as_val', a ? a.value : '', true), 'as_val')
      + fld('Date bought', dateInput('as_date', a ? a.date : today()), 'as_date')
      + fld('Note (optional)', textInput('as_note', a ? a.note : '', 'Second-hand…'))
      + '<button class="btn" id="as_save">' + (a ? 'Save' : 'Add asset') + '</button>' + (a ? '<button class="btn danger" id="as_del">Delete asset</button>' : '');
    return {
      title: a ? 'Edit asset' : 'Asset bought', html, after(root) {
        el<HTMLButtonElement>(root, 'as_save').onclick = () => {
          const name = fval(root, 'as_name'), value = num(fval(root, 'as_val')), date = fval(root, 'as_date');
          if (!setErr(root, 'as_name', name ? '' : 'Enter a name')) return;
          if (!setErr(root, 'as_val', value > 0 ? '' : 'Enter the cost')) return;
          if (!setErr(root, 'as_date', date ? '' : 'Pick the date')) return;
          const data = { name, value, date, note: fval(root, 'as_note') };
          const cur = a ? db().assets.find(x => sameId(x.id, id)) : undefined;
          if (cur) Object.assign(cur, data); else db().assets.push({ id: uid(), ...data });
          commit(); finishForm(); toast('Asset saved');
        };
        if (a) el<HTMLButtonElement>(root, 'as_del').onclick = () => {
          const undo = removeWithUndo(() => db().assets, x => sameId(x.id, id));
          commit(); finishForm(); toast('Asset deleted', undo);
        };
      }
    };
  };
}
ACT.editAsset = e => formSheet(assetForm(e.dataset.id || null));

/* ============================================================ CUSTOMER (view only) */
const MFIELDS: [string, string][] = [['bust', 'Bust'], ['waist', 'Waist'], ['backShoulder', 'Back shoulder'], ['halfShoulder', 'Half shoulder'], ['shoulderToBust', 'Shoulder to bust'], ['shoulderToWaist', 'Shoulder to waist'], ['hip', 'Hip'], ['sleeve', 'Sleeve'], ['sleeveCup', 'Sleeve cup'], ['skirtLength', 'Skirt length'], ['coatLength', 'Coat length'], ['height', 'Height']];
/** Known measurements first, then any other stored key, so nothing saved is hidden. */
function measurementKeys(m: Record<string, unknown>): [string, string][] {
  const known = MFIELDS.map(f => f[0]);
  return MFIELDS.concat(Object.keys(m).filter(k => !known.includes(k)).map((k): [string, string] => [k, k]));
}
ACT.openCustomer = e => viewSheet((): View | null => {
  const d = db(), c = d.customers.find(x => sameId(x.id, e.dataset.id)); if (!c) return null;
  const m = c.m || {}, filled = measurementKeys(m).filter(f => m[f[0]] !== undefined && m[f[0]] !== null && m[f[0]] !== '');
  const ords = ordersForCustomer(d, c).sort((a, b) => String(b.created || '').localeCompare(String(a.created || '')));
  const paid = ords.filter(o => !isForeign(o)).reduce((s, o) => s + orderPaid(o), 0);
  let h = '<p class="note" style="margin:0 4px 10px">View only. This record is kept safe; update it in the planner app.</p>'
    + '<div class="card">' + (c.phone ? '<a class="kv" href="tel:' + esc(c.phone) + '" style="color:inherit;text-decoration:none"><span>Phone</span><b style="color:var(--main)">' + esc(c.phone) + '</b></a>' : '<div class="kv"><span>Phone</span><b>—</b></div>') + (c.note ? '<div class="kv"><span>Notes</span><b>' + esc(c.note) + '</b></div>' : '') + '<div class="kv"><span>Total paid you</span><b style="color:var(--in)">' + money(paid) + '</b></div></div>';
  h += '<div class="sec"><h2>Measurements (cm)</h2></div>' + (filled.length ? '<div class="mgrid">' + filled.map(f => '<div><span>' + esc(f[1]) + '</span><b>' + esc(m[f[0]]) + '</b></div>').join('') + '</div>' : '<div class="card">' + emptyBox('users', 'No measurements saved.') + '</div>');
  if (ords.length) h += '<div class="sec"><h2>Orders</h2></div><div class="card">' + ords.map(orderRow).join('') + '</div>';
  return { title: c.name || 'Customer', html: h };
});

function csvCell(v: unknown): string { const s = v == null ? '' : String(v); return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
function download(name: string, text: string, type: string): void {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1500);
}
ACT.customersCsv = () => {
  const d = db(), keys = MFIELDS.map(f => f[0]), labels = new Map(MFIELDS);
  d.customers.forEach(c => Object.keys(c.m || {}).forEach(k => { if (!keys.includes(k)) { keys.push(k); labels.set(k, k); } }));
  const head = ['Name', 'Phone', 'Notes', ...keys.map(k => labels.get(k) + ' (cm)'), 'Orders', 'Total paid (' + CUR() + ')'];
  const rows = d.customers.slice().sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''))).map(c => {
    const ords = ordersForCustomer(d, c);
    return [c.name, c.phone, c.note, ...keys.map(k => (c.m || {})[k]), ords.length, Math.round(ords.filter(o => !isForeign(o)).reduce((s, o) => s + orderPaid(o), 0))];
  });
  download('dagmawit-customers-' + today() + '.csv', '﻿' + [head, ...rows].map(r => r.map(csvCell).join(',')).join('\r\n'), 'text/csv;charset=utf-8');
};

/* ============================================================ SETTINGS & BACKUPS */
ACT.openSettings = () => { closeSide(); formSheet((): View => ({
  title: 'Settings',
  html: fld('Currency', textInput('st_cur', CUR(), 'Birr'))
    + fld('Website currency', textInput('st_fcur', FCUR(), 'USD'))
    + '<button class="btn" id="st_save">Save</button>'
    + '<div class="card" style="margin-top:18px"><div class="kv"><span>Signed in as</span><b>' + esc(UI.email) + '</b></div></div>'
    + '<button class="btn line" data-act="openBackups">' + icon('database-export') + 'Backups and restore</button>'
    + '<button class="btn line" id="st_json">' + icon('download') + 'Download all data (file)</button>'
    + '<button class="btn danger" id="st_out">Sign out</button>',
  after(root) {
    el<HTMLButtonElement>(root, 'st_save').onclick = () => { db().settings.currency = fval(root, 'st_cur') || 'Birr'; db().settings.fcurrency = fval(root, 'st_fcur') || 'USD'; commit(); finishForm(); toast('Settings saved'); };
    el<HTMLButtonElement>(root, 'st_json').onclick = () => download('dagmawit-data-' + today() + '.json', JSON.stringify(db(), null, 2), 'application/json');
    el<HTMLButtonElement>(root, 'st_out').onclick = async () => { await client().auth.signOut(); location.reload(); };
  }
})); };

ACT.openBackups = () => { closeSide(); formSheet((): View => ({
  title: 'Backups',
  html: '<p class="note" style="margin:0 4px 10px">Safety copies of everything, kept in the cloud and shared by both phones. One is made automatically each day.</p>'
    + '<button class="btn" id="bk_now" style="margin-top:0">' + icon('database-export') + 'Back up now</button>'
    + '<div class="card" id="bk_list" style="margin-top:12px">' + emptyBox('refresh', 'Loading…') + '</div>',
  after(root) {
    const paint = async (): Promise<void> => {
      const pts = await loadBackups(), box = opt(root, 'bk_list'); if (!box) return;
      box.innerHTML = pts.length ? pts.map(p => {
        const dt = new Date(p.ts), dd = p.data || { orders: [], expenses: [] };
        return '<button class="row" data-restore="' + esc(p.id) + '"><div class="body"><div class="t1">' + esc(p.label || 'Backup') + '</div><div class="t2">' + dt.toLocaleDateString('en', { day: 'numeric', month: 'short', year: 'numeric' }) + ' · ' + dt.toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit' }) + ' · ' + (dd.orders || []).length + ' orders, ' + (dd.expenses || []).length + ' expenses</div></div><span class="pillbtn">Restore</span></button>';
      }).join('') : emptyBox('database-export', 'No backups yet.');
      box.querySelectorAll<HTMLElement>('[data-restore]').forEach(b => b.onclick = async () => {
        const pill = b.querySelector<HTMLElement>('.pillbtn'); if (!pill) return;
        if (!b.dataset.armed) { b.dataset.armed = '1'; pill.textContent = 'Tap again to restore'; pill.style.background = 'var(--out)'; pill.style.color = '#fff'; return; }
        pill.textContent = 'Restoring…';
        const ok = await restoreBackup(b.dataset.restore || '');
        closeSheets(); toast(ok ? 'Restored. A copy of the data before the restore was saved too.' : 'Could not restore (offline?)');
      });
    };
    const btn = el<HTMLButtonElement>(root, 'bk_now');
    btn.onclick = async () => { btn.textContent = 'Backing up…'; const ok = await makeBackup('Manual copy', false); toast(ok ? 'Backup saved' : 'Could not back up (offline?)'); btn.innerHTML = icon('database-export') + 'Back up now'; void paint(); };
    void paint();
  }
})); };
