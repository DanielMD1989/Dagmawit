/* ============================================================
   ui.ts — app shell: page routing, bottom sheets (with a back
   stack), toasts with Undo, side menu, money hiding, sync status,
   and one delegated handler for every [data-act] button.
   ============================================================ */
import type { Id, Ym } from './types';
import { ACT, INPUT, PAGES, type PageName, type SheetFn } from './registry';
import { icon, type IconName } from './icons';
import { db, save, type SyncStatus } from './sync';
import { esc, fmtNum } from './util';
import { CATEGORIES } from './model';

/** Element by id; throws if the page markup is missing it (a programming error). */
export function $<T extends HTMLElement = HTMLElement>(id: string): T {
  const el = document.getElementById(id);
  if (!el) throw new Error('Missing #' + id);
  return el as T;
}

export const UI = {
  tab: 'home' as PageName,
  email: '',
  orders: { filter: 'owes' as 'owes' | 'paid' | 'all', q: '' },
  exp: { ym: null as Ym | null, filter: 'all' as 'all' | 'biz' | 'home', q: '', cat: null as string | null },
  rep: { ym: null as Ym | null },
  custQ: '',
  hideMoney: ((): boolean => { try { return localStorage.getItem('dagmawit:hideMoney') === '1'; } catch { return false; } })()
};

/* ---------- money ---------- */
export const CUR = (): string => db().settings.currency || 'Birr';
export const FCUR = (): string => db().settings.fcurrency || 'USD';
export function money(n: number, cur?: string): string { const c = cur || CUR(); return UI.hideMoney ? c + ' •••••' : c + ' ' + fmtNum(n); }
export function signed(n: number, cur?: string): string { return (n < 0 ? '−' : '') + money(Math.abs(n), cur); }
/** Number only, for tight spots where the currency is in the label. */
export function figure(n: number): string { return UI.hideMoney ? '•••••' : (n < 0 ? '−' : '') + fmtNum(Math.abs(n)); }

/* ---------- pages ---------- */
export function go(tab: PageName): void {
  UI.tab = tab;
  document.querySelectorAll<HTMLElement>('nav.tabs .tab').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  render(); window.scrollTo(0, 0);
}
export function render(): void {
  const p = PAGES[UI.tab] || PAGES.home;
  if (!p) return;
  $('view').innerHTML = '<h1 class="page">' + esc(p.title) + '</h1>' + p.render();
  if (sheetStack.length) renderSheet(false, true);   // keep an open view sheet up to date
}

/* ---------- bottom sheets with a back stack ----------
   View sheets (an order, a loan…) re-run on every data change so they
   always show current numbers. Form sheets ({form:true}) do NOT: a sync
   from the other phone must never wipe what is being typed. */
interface SheetEntry { fn: SheetFn; form: boolean; kind: 'page' | ''; }
const sheetStack: SheetEntry[] = [];
export function openSheet(fn: SheetFn, opts?: { form?: boolean; kind?: 'page' }): void {
  sheetStack.push({ fn, form: !!opts?.form, kind: opts?.kind || '' });
  renderSheet(true);
}
export function sheetBack(): void { sheetStack.pop(); if (sheetStack.length) renderSheet(true); else closeSheets(); }
/** After saving a form: return to the page underneath (an order page…),
 *  otherwise the job is done and all sheets close. */
export function finishForm(): void {
  sheetStack.pop();
  const top = sheetStack[sheetStack.length - 1];
  if (top && top.kind === 'page') renderSheet(true); else closeSheets();
}
export function closeSheets(): void {
  sheetStack.length = 0;
  $('sheet').classList.remove('show'); $('scrim').classList.remove('show');
  document.body.style.overflow = '';
}
function renderSheet(scrollTop: boolean, fromData = false): void {
  const top = sheetStack[sheetStack.length - 1];
  if (!top || (fromData && top.form)) return;
  const s = top.fn();
  if (!s) { sheetBack(); return; }
  const root = $('sheetIn'), sheet = $('sheet');
  const keep = scrollTop ? 0 : sheet.scrollTop;
  root.innerHTML = '<div class="grab"></div><div class="sheethead">'
    + '<button class="iconbtn' + (sheetStack.length > 1 ? '' : ' ghost') + '" data-act="sheetBack" aria-label="Back">' + icon('arrow-left') + '</button>'
    + '<h2>' + esc(s.title) + '</h2>'
    + '<button class="iconbtn" data-act="closeSheets" aria-label="Close">' + icon('x') + '</button></div>' + s.html;
  sheet.classList.add('show'); $('scrim').classList.add('show');
  document.body.style.overflow = 'hidden';
  sheet.scrollTop = keep;
  s.after?.(root);
}
ACT.sheetBack = () => sheetBack();
ACT.closeSheets = () => closeSheets();

/* ---------- toast, optionally with Undo ---------- */
let toastTimer: ReturnType<typeof setTimeout> | undefined;
let toastUndo: (() => void) | null = null;
export function toast(msg: string, undo?: () => void): void {
  const t = $('toast');
  toastUndo = undo || null;
  t.innerHTML = '<span>' + esc(msg) + '</span>' + (undo ? '<button data-act="undo">Undo</button>' : '');
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.classList.remove('show'); toastUndo = null; }, undo ? 6000 : 2200);
}
ACT.undo = () => { const f = toastUndo; toastUndo = null; $('toast').classList.remove('show'); if (f) { f(); commit(); toast('Restored'); } };

/** Save after an edit and refresh what is on screen. */
export function commit(): void { save(); render(); }

/** Remove matching items and return an undo that puts them back where they
 *  were. `getList` runs again at undo time: a sync may have replaced the data. */
export function removeWithUndo<T extends { id: Id }>(getList: () => T[] | undefined, pred: (x: T) => boolean): () => void {
  const list = getList() || [], removed: { i: number; item: T }[] = [];
  for (let i = list.length - 1; i >= 0; i--) { const x = list[i] as T; if (pred(x)) { list.splice(i, 1); removed.unshift({ i, item: x }); } }
  return () => {
    const now = getList(); if (!now) return;
    removed.forEach(r => { if (!now.some(x => String(x.id) === String(r.item.id))) now.splice(Math.min(r.i, now.length), 0, r.item); });
  };
}

/* ---------- side menu ---------- */
export function openSide(): void { $('side').classList.add('show'); $('sideScrim').classList.add('show'); }
export function closeSide(): void { $('side').classList.remove('show'); $('sideScrim').classList.remove('show'); }
ACT.openSide = openSide;
ACT.closeSide = closeSide;
ACT.go = el => { closeSide(); closeSheets(); go(el.dataset.tab as PageName); };
ACT.tab = el => go(el.dataset.tab as PageName);

/* ---------- hide money ---------- */
export function paintEye(): void {
  const b = $('eyeBtn');
  b.innerHTML = icon(UI.hideMoney ? 'eye-off' : 'eye');
  b.classList.toggle('on', UI.hideMoney);
  b.setAttribute('aria-label', UI.hideMoney ? 'Show amounts' : 'Hide amounts');
}
ACT.toggleMoney = () => {
  UI.hideMoney = !UI.hideMoney;
  try { localStorage.setItem('dagmawit:hideMoney', UI.hideMoney ? '1' : '0'); } catch { /* not critical */ }
  paintEye(); render(); toast(UI.hideMoney ? 'Amounts hidden' : 'Amounts shown');
};

/* ---------- sync status ---------- */
export function showStatus(s: SyncStatus): void {
  const el = document.getElementById('sync'); if (!el) return;
  el.className = 'syncdot ' + s;
  el.innerHTML = '<i></i>' + (s === 'off' ? 'Not synced' : s === 'saving' ? 'Saving' : '');
  el.title = s === 'off' ? 'Saved on this phone. Will sync when online.' : s === 'saving' ? 'Saving…' : 'Synced';
}

/* ---------- one delegated handler for all buttons and inputs ---------- */
export function installHandlers(): void {
  document.addEventListener('click', e => {
    const el = (e.target as Element | null)?.closest<HTMLElement>('[data-act]');
    if (!el) return;
    const fn = ACT[el.dataset.act || ''];
    if (fn) { e.preventDefault(); fn(el, e); }
  });
  document.addEventListener('input', e => {
    const el = (e.target as Element | null)?.closest<HTMLInputElement>('[data-input]');
    const fn = el && INPUT[el.dataset.input || ''];
    if (el && fn) fn(el);
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeSheets(); closeSide(); } });
}

/** Re-render a page while keeping the cursor in its search box. */
export function rerenderKeepingFocus(id: string): void {
  render();
  const el = document.getElementById(id) as HTMLInputElement | null;
  if (el) { el.focus(); const n = el.value.length; el.setSelectionRange(n, n); }
}

/* ---------- small HTML helpers ---------- */
export function emptyBox(ic: IconName, text: string): string { return '<div class="empty">' + icon(ic) + esc(text) + '</div>'; }
export function catIcon(cat: string): IconName { return CATEGORIES.find(x => x.k === cat)?.ic || 'receipt-2'; }
