/** Set by public/config.js at runtime, so the Supabase project can be
 *  changed without rebuilding the app. */
interface AtelierConfig { SUPABASE_URL: string; SUPABASE_ANON_KEY: string; }
interface Window { ATELIER_CONFIG?: AtelierConfig; }
