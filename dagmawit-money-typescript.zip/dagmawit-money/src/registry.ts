/* ============================================================
   registry.ts — the tables that connect buttons and pages to code.
   It imports nothing, so every other module can use it without
   creating import cycles.
   ============================================================ */

/** A button handler: <button data-act="name"> calls ACT.name(button, event). */
export type ActionFn = (el: HTMLElement, ev: Event) => void;
/** <input data-input="name"> calls INPUT.name(input) on every keystroke. */
export type InputFn = (el: HTMLInputElement) => void;

export interface Page { title: string; render(): string; }
/** What a sheet shows. A sheet function returns null when its record is gone. */
export interface SheetView { title: string; html: string; after?: (root: HTMLElement) => void; }
export type SheetFn = () => SheetView | null;

export type PageName = 'home' | 'orders' | 'expenses' | 'reports' | 'customers' | 'loans' | 'assets' | 'audit';

export const ACT: Record<string, ActionFn> = {};
export const INPUT: Record<string, InputFn> = {};
export const PAGES: Partial<Record<PageName, Page>> = {};
