/* ============================================================
   main.ts — start-up and sign-in. There is deliberately no
   "create account": only the two existing accounts may use the
   app (see sql/restrict-access.sql).
   ============================================================ */
import './styles.css';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { icon, type IconName } from './icons';
import { $, UI, installHandlers, paintEye, render, showStatus } from './ui';
import { maybeAutoBackup, syncStart } from './sync';
import type { PageName } from './registry';
// Importing these registers the pages and the button actions.
import './screens';
import './forms';

type View = 'loadingView' | 'authView' | 'appView';
function showOnly(id: View): void { (['loadingView', 'authView', 'appView'] as View[]).forEach(v => { $(v).style.display = v === id ? '' : 'none'; }); }
function authMsg(text: string, ok = false): void { const m = $('au_msg'); m.textContent = text; m.className = ok ? 'hint ok' : 'err'; }

function paintShell(): void {
  $('menuBtn').innerHTML = icon('menu-2');
  paintEye();
  const tabs: Record<string, [IconName, string]> = { home: ['home', 'Home'], orders: ['receipt-2', 'Orders'], expenses: ['wallet', 'Expenses'], reports: ['chart-bar', 'Reports'] };
  document.querySelectorAll<HTMLElement>('nav.tabs .tab').forEach(b => { const t = tabs[b.dataset.tab || '']; if (t) b.innerHTML = icon(t[0]) + t[1]; });
  $('addBtn').innerHTML = '<span>' + icon('plus') + '</span>';
  const side: [PageName, IconName, string][] = [['customers', 'users', 'Customers'], ['loans', 'building-bank', 'Loans'], ['assets', 'building-factory-2', 'Assets'], ['audit', 'calculator', 'Check the numbers']];
  $('sideItems').innerHTML = side.map(s => '<button class="item" data-act="go" data-tab="' + s[0] + '">' + icon(s[1]) + s[2] + '</button>').join('')
    + '<button class="item" data-act="openBackups">' + icon('database-export') + 'Backups</button>'
    + '<button class="item" data-act="openSettings">' + icon('settings') + 'Settings</button>';
}

async function boot(sb: SupabaseClient): Promise<void> {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) { showOnly('authView'); return; }
  UI.email = session.user.email || '';
  showOnly('loadingView');
  paintShell();
  try {
    await syncStart(sb, () => { if ($('appView').style.display !== 'none') render(); }, showStatus);
  } catch (e) { console.error(e); showStatus('off'); }
  showOnly('appView');
  render();
  setTimeout(() => { void maybeAutoBackup(); }, 5000);
}

function start(): void {
  installHandlers();
  const cfg = window.ATELIER_CONFIG;
  if (!cfg || !cfg.SUPABASE_URL || cfg.SUPABASE_URL.startsWith('PASTE')) { showOnly('authView'); authMsg('Not set up yet: add the Supabase address and key in config.js.'); return; }
  const sb = createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  $<HTMLFormElement>('au_form').onsubmit = async ev => {
    ev.preventDefault();
    const email = $<HTMLInputElement>('au_email').value.trim(), password = $<HTMLInputElement>('au_pass').value;
    if (!email || !password) { authMsg('Enter your email and password.'); return; }
    const btn = $<HTMLButtonElement>('au_btn');
    btn.disabled = true; authMsg('Signing in…', true);
    const { error } = await sb.auth.signInWithPassword({ email, password });
    btn.disabled = false;
    if (error) { authMsg(error.message === 'Invalid login credentials' ? 'Wrong email or password.' : error.message); return; }
    authMsg(''); void boot(sb);
  };
  boot(sb).catch(e => { console.error(e); showOnly('authView'); authMsg('Could not connect. Check the internet and try again.'); });
}

start();
