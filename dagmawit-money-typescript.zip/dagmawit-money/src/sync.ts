/* ============================================================
   sync.ts — keeps this phone and the cloud in step.

   The business is one document in Supabase (table business_data,
   row id 'shared'), plus a 'backups' row. To stop two phones from
   overwriting each other:
   • every save is CONDITIONAL: "write only if the cloud still has
     the version I last saw" (matched on updated_at);
   • if someone else saved first, their version is fetched and the
     two are MERGED record by record (model.ts mergeDocs), then the
     save is retried;
   • edits made offline stay on the phone and are merged the same
     way when the connection returns.
   All cloud work runs one step at a time through a queue, so a save
   and a refresh can never race each other.
   ============================================================ */
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Doc } from './types';
import { emptyDoc, mergeDocs, normalize } from './model';
import { clone, same, today, uid } from './util';

export type SyncStatus = 'synced' | 'saving' | 'off';
interface Row { content: unknown; updated_at: string; }

const SHARED_ID = 'shared';
const LS = { data: 'dagmawit:data', base: 'dagmawit:base', baseTs: 'dagmawit:baseTs', dirty: 'dagmawit:dirty' } as const;

const S = {
  sb: null as SupabaseClient | null,
  mem: emptyDoc(),
  /** the cloud version this phone last agreed with (raw, as stored) */
  base: null as unknown,
  baseTs: null as string | null,
  dirty: false,
  queue: Promise.resolve() as Promise<void>,
  timer: 0 as ReturnType<typeof setTimeout> | 0,
  onChange: (): void => { },
  onStatus: (_s: SyncStatus): void => { }
};

/** The live business data. Screens read it; forms change it, then call save(). */
export function db(): Doc { return S.mem; }
export function client(): SupabaseClient { if (!S.sb) throw new Error('Not connected'); return S.sb; }

function lsGet(k: string): unknown { try { const r = localStorage.getItem(k); return r == null ? null : JSON.parse(r); } catch { return null; } }
function lsSet(k: string, v: unknown): void { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage full or blocked: cloud copy still works */ } }
function persist(): void { lsSet(LS.data, S.mem); lsSet(LS.base, S.base); lsSet(LS.baseTs, S.baseTs); lsSet(LS.dirty, S.dirty ? 1 : 0); }
const setStatus = (s: SyncStatus): void => S.onStatus(s);
const baseDoc = (): Doc | null => S.base == null ? null : normalize(clone(S.base));

/** Run cloud work one step at a time. */
export function serial(fn: () => Promise<void>): Promise<void> {
  S.queue = S.queue.then(fn).catch((e: unknown) => { console.error(e); setStatus('off'); });
  return S.queue;
}

async function fetchRemote(): Promise<Row | null> {
  const { data, error } = await client().from('business_data').select('content,updated_at').eq('id', SHARED_ID).maybeSingle();
  if (error) throw error;
  return data as Row | null;
}

/** Bring the cloud version in: replaces the phone copy if there are no local
 *  edits, merges with them otherwise. */
export async function pull(): Promise<void> {
  if (!navigator.onLine) { setStatus('off'); return; }
  const r = await fetchRemote();
  if (!r) {                                    // brand-new project: create the row
    const ts = new Date().toISOString();
    const { error } = await client().from('business_data').insert({ id: SHARED_ID, content: S.mem, updated_at: ts });
    if (error) throw error;
    S.base = clone(S.mem); S.baseTs = ts; S.dirty = false; persist(); setStatus('synced');
    return;
  }
  if (r.updated_at === S.baseTs) { setStatus(S.dirty ? 'saving' : 'synced'); return; }
  const remote = normalize(clone(r.content));
  if (S.dirty) S.mem = mergeDocs(baseDoc(), S.mem, remote);
  else {
    S.mem = remote;
    if (!same(remote, r.content)) S.dirty = true;     // the one-time data upgrade needs saving
  }
  S.base = r.content; S.baseTs = r.updated_at;
  persist(); S.onChange();
  if (S.dirty) await push(); else setStatus('synced');
}

/** Save to the cloud, only if nobody else saved in between. */
export async function push(): Promise<void> {
  if (!navigator.onLine) { setStatus('off'); return; }
  for (let attempt = 0; attempt < 6 && S.dirty; attempt++) {
    if (!S.baseTs) { await pull(); continue; }
    setStatus('saving');
    const snapshot = clone(S.mem), ts = new Date().toISOString();
    const { data, error } = await client().from('business_data')
      .update({ content: snapshot, updated_at: ts })
      .eq('id', SHARED_ID).eq('updated_at', S.baseTs)
      .select('updated_at');
    if (error) throw error;
    const saved = (data || []) as { updated_at: string }[];
    if (saved[0]) {
      S.base = snapshot; S.baseTs = saved[0].updated_at;
      S.dirty = !same(S.mem, snapshot);            // edits made while saving stay pending
      persist();
      continue;
    }
    // Someone else saved first: merge their changes with ours, then retry.
    const r = await fetchRemote();
    if (!r) { S.baseTs = null; continue; }
    S.mem = mergeDocs(baseDoc(), S.mem, normalize(clone(r.content)));
    S.base = r.content; S.baseTs = r.updated_at;
    persist(); S.onChange();
  }
  setStatus(S.dirty ? 'off' : 'synced');
}

const pullThenPush = async (): Promise<void> => { await pull(); if (S.dirty) await push(); };

/** Call after every edit: saved on the phone at once, to the cloud shortly after. */
export function save(): void {
  S.dirty = true; persist();
  if (!navigator.onLine) { setStatus('off'); return; }
  setStatus('saving');
  if (S.timer) clearTimeout(S.timer);
  S.timer = setTimeout(() => { void serial(push); }, 500);
}

export async function syncStart(sb: SupabaseClient, onChange: () => void, onStatus: (s: SyncStatus) => void): Promise<void> {
  S.sb = sb; S.onChange = onChange; S.onStatus = onStatus;
  S.base = lsGet(LS.base);
  const ts = lsGet(LS.baseTs); S.baseTs = typeof ts === 'string' ? ts : null;
  S.dirty = !!lsGet(LS.dirty);
  const local = lsGet(LS.data);
  S.mem = normalize(local ? clone(local) : emptyDoc());
  if (!local) S.dirty = false;
  await serial(pullThenPush);                        // also sends edits made while offline

  sb.channel('biz').on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'business_data', filter: 'id=eq.' + SHARED_ID }, p => {
    const n = p.new as Partial<Row> | undefined;
    if (n && n.updated_at && n.updated_at === S.baseTs) return;   // our own save coming back
    void serial(pull);
  }).subscribe();
  window.addEventListener('online', () => { void serial(pullThenPush); });
  window.addEventListener('offline', () => setStatus('off'));
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') void serial(pull); });
  setInterval(() => { if (document.visibilityState === 'visible' && navigator.onLine) void serial(pull); }, 30000);
}

/** Replace everything (used by "restore backup"). */
export function replaceAll(doc: unknown): void { S.mem = normalize(clone(doc)); save(); S.onChange(); }

/* ============================================================
   BACKUPS — rolling restore points in the 'backups' row (shared by
   both phones). An automatic copy at most once a day per phone.
   ============================================================ */
export interface BackupPoint { id: string; ts: string; label: string; auto: boolean; data: Doc; }
const BACKUP_ID = 'backups', MAX_POINTS = 12, LS_LASTBACKUP = 'dagmawit:lastAutoBackup';

export async function loadBackups(): Promise<BackupPoint[]> {
  const { data, error } = await client().from('business_data').select('content').eq('id', BACKUP_ID).maybeSingle();
  if (error || !data) return [];
  const c = (data as { content: unknown }).content as { points?: unknown } | null;
  return c && Array.isArray(c.points) ? c.points as BackupPoint[] : [];
}
async function saveBackups(points: BackupPoint[]): Promise<void> {
  const { data } = await client().from('business_data').select('id').eq('id', BACKUP_ID).maybeSingle();
  const ts = new Date().toISOString();
  const res = data
    ? await client().from('business_data').update({ content: { points }, updated_at: ts }).eq('id', BACKUP_ID)
    : await client().from('business_data').insert({ id: BACKUP_ID, content: { points }, updated_at: ts });
  if (res.error) throw res.error;
}
export async function makeBackup(label: string, auto: boolean): Promise<boolean> {
  if (!navigator.onLine) return false;
  try {
    const points = await loadBackups();
    points.unshift({ id: uid(), ts: new Date().toISOString(), label, auto, data: clone(S.mem) });
    await saveBackups(points.slice(0, MAX_POINTS));
    return true;
  } catch (e) { console.error(e); return false; }
}
export async function maybeAutoBackup(): Promise<void> {
  if (lsGet(LS_LASTBACKUP) === today()) return;
  if (await makeBackup('Automatic copy', true)) lsSet(LS_LASTBACKUP, today());
}
export async function restoreBackup(id: string): Promise<boolean> {
  const p = (await loadBackups()).find(x => x.id === id);
  if (!p || !p.data) return false;
  await makeBackup('Before restore', true);          // so the restore itself can be undone
  replaceAll(p.data);
  return true;
}
