/* ============================================================
   util.ts — small shared helpers. No DOM access, so the unit
   tests can import it directly.
   ============================================================ */
import type { Id, Ym, Ymd } from './types';

/* ---------- dates: always the phone's LOCAL calendar day ----------
   toISOString() is UTC: in Addis Ababa it gives yesterday's date
   between midnight and 3 a.m., so it is never used for dates. */
const pad2 = (n: number): string => String(n).padStart(2, '0');
export function ymdOf(d: Date): Ymd { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
export function today(): Ymd { return ymdOf(new Date()); }
export function parseYmd(s: Ymd): Date { const p = String(s).split('-').map(Number); return new Date(p[0] ?? 1970, (p[1] ?? 1) - 1, p[2] || 1); }
export function addDays(s: Ymd, n: number): Ymd { const d = parseYmd(s); d.setDate(d.getDate() + n); return ymdOf(d); }
export function addMonths(s: Ymd, n: number): Ymd {
  const d = parseYmd(s), day = d.getDate();
  d.setDate(1); d.setMonth(d.getMonth() + n);
  const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  d.setDate(Math.min(day, last));
  return ymdOf(d);
}
export function daysBetween(a: Ymd, b: Ymd): number { return Math.round((parseYmd(b).getTime() - parseYmd(a).getTime()) / 86400000); }
export function ymOf(s: Ymd | undefined | null): Ym { return String(s || '').slice(0, 7); }
export function shiftYm(ym: Ym, n: number): Ym { const [y = 1970, m = 1] = ym.split('-').map(Number); const d = new Date(y, m - 1 + n, 1); return d.getFullYear() + '-' + pad2(d.getMonth() + 1); }
export function monthRange(ym: Ym): [Ymd, Ymd] { const [y = 1970, m = 1] = ym.split('-').map(Number); return [ym + '-01', ym + '-' + pad2(new Date(y, m, 0).getDate())]; }
export function monthLabel(ym: Ym, short?: boolean): string { const [y = 1970, m = 1] = ym.split('-').map(Number); return new Date(y, m - 1, 1).toLocaleDateString('en', short ? { month: 'short' } : { month: 'long', year: 'numeric' }); }
export function niceDate(s: Ymd | undefined | null): string {
  if (!s) return 'No date';
  const t = today();
  if (s === t) return 'Today';
  if (s === addDays(t, -1)) return 'Yesterday';
  return parseYmd(s).toLocaleDateString('en', s.slice(0, 4) === t.slice(0, 4) ? { day: 'numeric', month: 'short' } : { day: 'numeric', month: 'short', year: 'numeric' });
}

/* ---------- ids, numbers, text ---------- */
export function uid(): string { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
export const sameId = (a: Id | null | undefined, b: Id | null | undefined): boolean => a != null && b != null && String(a) === String(b);
/** Any value to a finite number (bad input becomes 0). */
export function num(v: unknown): number { const n = Number(v); return Number.isFinite(n) ? n : 0; }
export function fmtNum(n: unknown): string { return Math.round(num(n)).toLocaleString('en'); }
export function esc(s: unknown): string { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string)); }
export function words(s: unknown): string[] { return String(s || '').toLowerCase().split(/[^a-z0-9ሀ-፿]+/).filter(w => w.length > 2); }
export const lower = (s: unknown): string => String(s || '').trim().toLowerCase();

/* ---------- deep copy / compare (key order independent: the
   database (jsonb) may return object keys in a different order) */
export function clone<T>(x: T): T { return x === undefined ? x : JSON.parse(JSON.stringify(x)) as T; }
export function stableStringify(v: unknown): string {
  if (v === null || typeof v !== 'object') return JSON.stringify(v === undefined ? null : v);
  if (Array.isArray(v)) return '[' + v.map(stableStringify).join(',') + ']';
  const o = v as Record<string, unknown>;
  return '{' + Object.keys(o).filter(k => o[k] !== undefined).sort().map(k => JSON.stringify(k) + ':' + stableStringify(o[k])).join(',') + '}';
}
export function same(a: unknown, b: unknown): boolean { return stableStringify(a) === stableStringify(b); }
export const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
