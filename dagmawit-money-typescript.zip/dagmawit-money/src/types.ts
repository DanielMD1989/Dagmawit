/* ============================================================
   types.ts — the shape of the business data.

   Every record keeps an index signature ([k: string]: unknown)
   on purpose: the stored data also holds fields this app does not
   use (planner fields such as measurements on old orders, delivery
   dates, events…). They must survive every save untouched, so the
   types allow them instead of stripping them.
   ============================================================ */

/** Ids are strings for new records; very old records may hold numbers. */
export type Id = string | number;
export type Scope = 'biz' | 'home';
export type Freq = 'once' | 'week' | 'month' | 'quarter';
/** A calendar day as 'YYYY-MM-DD' (local time). */
export type Ymd = string;
/** A month as 'YYYY-MM'. */
export type Ym = string;

export interface Payment {
  id: Id;
  amount: number;
  date: Ymd;
  note?: string;
  [k: string]: unknown;
}

export interface Order {
  id: Id;
  created?: Ymd;
  customer?: string;
  customerId?: Id | null;
  phone?: string;
  clothType?: string;
  total: number;
  /** Copy of the payments total, kept for backups and older readers. */
  paid?: number;
  payments: Payment[];
  currency?: 'local' | 'foreign' | string;
  orderType?: 'custom' | 'bazar' | string;
  channel?: string;
  payType?: string;
  delivered?: boolean;
  deliveredOn?: Ymd;
  [k: string]: unknown;
}

export interface Expense {
  id: Id;
  cat: string;
  amount: number;
  date: Ymd;
  scope?: Scope | string;
  note?: string;
  employee?: string;
  recurring?: boolean;
  freq?: Freq | string;
  /** Set on loan repayments: these are NOT expenses. */
  loanId?: Id;
  /** Legacy fabric-roll usage entries. */
  rollId?: Id;
  [k: string]: unknown;
}

export interface Loan {
  id: Id;
  lender?: string;
  total: number;
  received?: Ymd;
  created?: Ymd;
  note?: string;
  purpose?: string;
  [k: string]: unknown;
}

export interface Asset {
  id: Id;
  name?: string;
  value: number;
  date?: Ymd;
  note?: string;
  [k: string]: unknown;
}

export interface Customer {
  id: Id;
  name?: string;
  phone?: string;
  note?: string;
  /** Measurements in cm, managed by the planner app (view only here). */
  m?: Record<string, number | string | null>;
  [k: string]: unknown;
}

export interface Settings {
  currency: string;
  fcurrency: string;
  [k: string]: unknown;
}

export interface Doc {
  schema?: number;
  orders: Order[];
  expenses: Expense[];
  loans: Loan[];
  rolls: unknown[];
  events: unknown[];
  customers: Customer[];
  assets: Asset[];
  settings: Settings;
  [k: string]: unknown;
}

/** One movement of money. Every total is computed from these. */
export type Flow =
  | { kind: 'in' | 'fin'; date: Ymd; amount: number; order: Order; pay: Payment }
  | { kind: 'out' | 'repay'; date: Ymd; amount: number; scope: Scope; exp: Expense }
  | { kind: 'loan'; date: Ymd; amount: number; loan: Loan }
  | { kind: 'asset'; date: Ymd; amount: number; asset: Asset };

export interface Totals {
  income: number;
  work: number;
  home: number;
  repaid: number;
  borrowed: number;
  assets: number;
  /** Website orders, in the foreign currency (kept separate). */
  fIncome: number;
  spent: number;
  profit: number;
  cashIn: number;
  cashOut: number;
  net: number;
}

export interface MonthTotals extends Totals { ym: Ym; cashEnd: number; }

export interface OwedGroup {
  key: string;
  name: string;
  phone: string;
  left: number;
  orders: Order[];
  oldest: Ymd;
}

export interface Due { exp: Expense; next: Ymd; days: number; }

export interface ScopeSuggestion { scope: Scope; learned: boolean; text: string; }

export interface QuickPick {
  cat: string; scope: Scope; note: string; employee: string;
  count: number; last: Ymd; amount: number; recurring: boolean; freq: string;
}

export interface Category { k: string; ic: import('./icons').IconName; def: Scope | null; }
